import * as i0 from '@angular/core';
import { Injectable, Input, Component, inject, ElementRef, Renderer2, ViewContainerRef, Directive, TemplateRef, ContentChild, Host, Self } from '@angular/core';
import { NgClass, NgIf, NgFor, NgSwitch, NgSwitchCase, NgTemplateOutlet } from '@angular/common';

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * Per-snippet clipboard state. Intentionally NOT `providedIn: 'root'` —
 * each <omni-snippets> instance gets its own via the component's
 * `providers: [CopyService]`, otherwise multiple snippets on the same page
 * would stomp each other's clipboard buffer.
 */
class CopyService {
    constructor() {
        this._textToCopy = '';
        this._linesToCopy = {};
    }
    set(text) {
        this._textToCopy = text;
    }
    get() {
        return this._textToCopy;
    }
    add(text) {
        this._textToCopy += text;
    }
    setLine(number, line) {
        if (!line) {
            delete this._linesToCopy[number];
        }
        else {
            this._linesToCopy[number] = line;
        }
        this._textToCopy = Object.values(this._linesToCopy).join(`\n`);
    }
    toClipboard() {
        if (!navigator?.clipboard?.writeText) {
            return Promise.reject(new Error('Clipboard API unavailable'));
        }
        return navigator.clipboard.writeText(this._textToCopy).catch((err) => {
            // Surface the failure so callers can react; silent rejection masked
            // real bugs (e.g. running on insecure context / permissions denied).
            console.error('Failed to copy to clipboard', err);
            throw err;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CopyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CopyService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CopyService, decorators: [{
            type: Injectable
        }] });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @internal
 * @description
 * A component used for showing the line numbers in the gutter as well as handling
 * single line copy functionality
 */
class NumberLineComponent {
    constructor(elementRef, renderer, copyService) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.copyService = copyService;
        this.selected = false;
        this.valueForCopy = '';
        this.self = this.elementRef.nativeElement;
    }
    selectLine() {
        this.handleSelect(this.self);
        this.copyService.setLine(this.number, this.valueForCopy);
        void this.copyService.toClipboard();
    }
    handleSelect(element) {
        this.valueForCopy = '';
        const coordinates = element.getBoundingClientRect();
        const offset = Math.round(coordinates.width) + 11;
        const nextInLine = document.elementsFromPoint(coordinates.x + offset, coordinates.y + coordinates.height / 2)[0];
        try {
            if (nextInLine.hasAttribute('row-num')) {
                this.setLine(nextInLine);
            }
            else if (nextInLine.parentElement) {
                this.setLine(nextInLine.parentElement);
            }
        }
        catch {
            throw new Error('Failed to locate the code line');
        }
    }
    setLine(element) {
        if (element.classList.contains('selected-line')) {
            this.renderer.removeClass(element, 'selected-line');
            this.selected = false;
        }
        else {
            this.renderer.addClass(element, 'selected-line');
            this.setCopyValue(element);
            this.selected = true;
        }
    }
    setCopyValue(element) {
        const spans = element.children;
        for (let i = 0; i < spans.length; i++) {
            this.valueForCopy += spans[i].textContent ?? '';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: NumberLineComponent, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: CopyService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.21", type: NumberLineComponent, isStandalone: true, selector: "omni-number-line", inputs: { number: "number" }, ngImport: i0, template: "<div class=\"number-line\" [ngClass]=\"{ 'selected-line-number': selected }\">\r\n  <span\r\n    class=\"digit\"\r\n    [ngClass]=\"{ 'selected-digit': selected }\"\r\n    (click)=\"selectLine()\"\r\n    >{{ number }}\r\n  </span>\r\n</div>\r\n", styles: [".number-line{position:relative;display:flex;justify-content:flex-end;width:inherit;cursor:pointer;color:var(--snippet-header-text-color);background-color:var(--snippet-background-color);filter:brightness(120%)}.number-line .digit{background:none;padding-right:10px}.number-line .digit:hover{color:var(--number-line-hover-color);transform:scale(1.2)}.selected-line-number{filter:brightness(140%);border-left:2px solid var(--snippet-header-text-color)}.selected-digit{color:var(--number-line-highlight-color)}\n", "@property --snippet-font-size{syntax: \"<length>\"; inherits: true; initial-value: 13px;}@property --snippets-header-font-size{syntax: \"<length>\"; inherits: true; initial-value: 12px;}@property --snippet-letter-spacing{syntax: \"<length>\"; inherits: true; initial-value: 1px;}@property --snippet-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 5px;}@property --snippet-tab-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 2px;}@property --snippets-gutter-width{syntax: \"<length>\"; inherits: true; initial-value: 72px;}@property --snippets-scrollbar-width{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippets-scrollbar-height{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippet-background-color{syntax: \"<color>\"; inherits: true; initial-value: #202836;}@property --snippet-header-background-color{syntax: \"<color>\"; inherits: true; initial-value: #1a212b;}@property --snippet-header-text-color{syntax: \"<color>\"; inherits: true; initial-value: #61789e;}@property --number-line-highlight-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --number-line-hover-color{syntax: \"<color>\"; inherits: true; initial-value: #07cc8a;}@property --control-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #e1955d;}@property --context-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --declaration-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #22e2b8;}@property --quoted-token-color{syntax: \"<color>\"; inherits: true; initial-value: #34ec71;}@property --data-token-color{syntax: \"<color>\"; inherits: true; initial-value: #a98adf;}@property --function-token-color{syntax: \"<color>\"; inherits: true; initial-value: #44b7ff;}@property --separator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #676e70;}@property --property-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --operator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f8c49e;}@property --parameter-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f371a6;}@property --var-token-color{syntax: \"<color>\"; inherits: true; initial-value: #cfddd2;}@property --comment-token-color{syntax: \"<color>\"; inherits: true; initial-value: gray;}@property --text-token-color{syntax: \"<color>\"; inherits: true; initial-value: lightgray;}@property --element-token-color{syntax: \"<color>\"; inherits: true; initial-value: salmon;}@property --attribute-color{syntax: \"<color>\"; inherits: true; initial-value: #ffd255;}@property --special-char-token-color{syntax: \"<color>\"; inherits: true; initial-value: #4cdaab;}@property --selector-token-color{syntax: \"<color>\"; inherits: true; initial-value: #daa14c;}@property --prop-token-color{syntax: \"<color>\"; inherits: true; initial-value: #da4cc7;}@property --check-icon-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --copy-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M360-240q-33 0-56.5-23.5T280-320v-480q0-33 23.5-56.5T360-880h360q33 0 56.5 23.5T800-800v480q0 33-23.5 56.5T720-240H360Zm0-80h360v-480H360v480ZM200-80q-33 0-56.5-23.5T120-160v-560h80v560h440v80H200Zm160-240v-480 480Z\";}@property --check-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z\";}*{--_snippet-font: var( --snippet-font, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif );font-family:var(--_snippet-font)}\n/**\n * @license\n * Copyright Slavko Mihajlovic All Rights Reserved.\n *\n * Use of this source code is governed by an ISC-style license that can be\n * found at https://www.isc.org/licenses/\n */\n", ".snippets-content{--_fill-color: var(--snippet-header-text-color);width:inherit;height:inherit;min-height:40px;border-radius:var(--snippet-border-radius);background-color:var(--snippet-background-color);margin:0 auto;overflow:hidden;position:relative;z-index:2}.snippets-content *{background:none}.snippets-content .snippets-header{width:auto;height:auto;display:flex;justify-content:flex-end;background-color:var(--snippet-header-background-color)!important;border-radius:var(--snippet-border-radius) var(--snippet-border-radius) 0 0;font-size:var(--snippets-header-font-size)}.snippets-content .snippets-header .snippet-tab{padding:5px;border-radius:0px 0px var(--snippet-tab-border-radius) var(--snippet-tab-border-radius);color:var(--snippet-header-text-color);cursor:pointer}.snippets-content .snippets-header .snippet-tab:hover{filter:brightness(150%);-webkit-backdrop-filter:brightness(60%);backdrop-filter:brightness(60%)}.snippets-content .snippets-header .active-tab{filter:brightness(150%);-webkit-backdrop-filter:brightness(50%);backdrop-filter:brightness(50%)}.snippets-content .copy-button svg,.snippets-content .snippets-header .copy-tab svg{fill:var(--_fill-color)}.snippets-content .copy-button svg path,.snippets-content .snippets-header .copy-tab svg path{d:path(var(--copy-icon-path))}.snippets-content .copy-button svg:hover,.snippets-content .snippets-header .copy-tab svg:hover{filter:brightness(150%)}.snippets-content .copy-button:active,.snippets-content .snippets-header .copy-tab:active{--copy-icon-path: var(--check-icon-path);--_fill-color: var(--check-icon-color)}.snippets-content .snippets-header .copy-tab svg{height:calc(var(--snippets-header-font-size) - 1px);width:calc(var(--snippets-header-font-size) - 1px)}.snippets-content .copy-button{position:absolute;top:5px;right:5px;display:flex;justify-content:center;align-items:center;background-color:var(--snippet-header-background-color);border-radius:2px;height:calc(var(--snippet-font-size) + 3px);width:calc(var(--snippet-font-size) + 3px)}.snippets-content .copy-button svg{height:calc(var(--snippet-font-size) + 1px);width:calc(var(--snippet-font-size) + 1px)}.snippets-content .snippets-code-lines{min-height:inherit;width:100%;height:100%;border-radius:0 0 var(--snippet-border-radius) var(--snippet-border-radius)}.snippets-content .snippets-code-lines pre{margin:5px 0}.snippets-content .snippets-gutter{display:block;width:var(--snippets-gutter-width);height:100%;min-width:var(--snippets-gutter-width);min-height:inherit;pointer-events:auto;flex-direction:column;align-items:flex-end;color:var(--snippet-header-text-color);padding:5px 0;border-right:1px solid var(--snippet-header-text-color);-webkit-backdrop-filter:brightness(120%);backdrop-filter:brightness(120%)}.snippets-content .snippets-code-lines,.snippets-content .snippets-gutter{font-size:var(--snippet-font-size);letter-spacing:var(--snippet-letter-spacing);height:100%}.snippets-content .selected-line{filter:brightness(130%);background-color:var(--snippet-background-color);-webkit-backdrop-filter:brightness(150%);backdrop-filter:brightness(150%)}.snippets-content .line{display:block;padding-left:10px}.snippets-content .line-focus{-webkit-backdrop-filter:hue-rotate(-25deg);backdrop-filter:hue-rotate(-25deg);border-top:1px solid var(--snippet-header-text-color);border-bottom:1px solid var(--snippet-header-text-color);margin:-1px 0}.snippets-content .snippets{display:flex;flex-direction:row;overflow:auto;min-height:inherit;scrollbar-width:thin;scrollbar-color:var(--snippet-header-text-color) var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar{width:var(--snippets-scrollbar-width);height:var(--snippets-scrollbar-height)}.snippets-content .snippets::-webkit-scrollbar-track{border-radius:2px;background-color:var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar-thumb{border-radius:2px;background-color:var(--snippet-header-text-color)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: NumberLineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'omni-number-line', imports: [NgClass], template: "<div class=\"number-line\" [ngClass]=\"{ 'selected-line-number': selected }\">\r\n  <span\r\n    class=\"digit\"\r\n    [ngClass]=\"{ 'selected-digit': selected }\"\r\n    (click)=\"selectLine()\"\r\n    >{{ number }}\r\n  </span>\r\n</div>\r\n", styles: [".number-line{position:relative;display:flex;justify-content:flex-end;width:inherit;cursor:pointer;color:var(--snippet-header-text-color);background-color:var(--snippet-background-color);filter:brightness(120%)}.number-line .digit{background:none;padding-right:10px}.number-line .digit:hover{color:var(--number-line-hover-color);transform:scale(1.2)}.selected-line-number{filter:brightness(140%);border-left:2px solid var(--snippet-header-text-color)}.selected-digit{color:var(--number-line-highlight-color)}\n", "@property --snippet-font-size{syntax: \"<length>\"; inherits: true; initial-value: 13px;}@property --snippets-header-font-size{syntax: \"<length>\"; inherits: true; initial-value: 12px;}@property --snippet-letter-spacing{syntax: \"<length>\"; inherits: true; initial-value: 1px;}@property --snippet-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 5px;}@property --snippet-tab-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 2px;}@property --snippets-gutter-width{syntax: \"<length>\"; inherits: true; initial-value: 72px;}@property --snippets-scrollbar-width{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippets-scrollbar-height{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippet-background-color{syntax: \"<color>\"; inherits: true; initial-value: #202836;}@property --snippet-header-background-color{syntax: \"<color>\"; inherits: true; initial-value: #1a212b;}@property --snippet-header-text-color{syntax: \"<color>\"; inherits: true; initial-value: #61789e;}@property --number-line-highlight-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --number-line-hover-color{syntax: \"<color>\"; inherits: true; initial-value: #07cc8a;}@property --control-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #e1955d;}@property --context-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --declaration-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #22e2b8;}@property --quoted-token-color{syntax: \"<color>\"; inherits: true; initial-value: #34ec71;}@property --data-token-color{syntax: \"<color>\"; inherits: true; initial-value: #a98adf;}@property --function-token-color{syntax: \"<color>\"; inherits: true; initial-value: #44b7ff;}@property --separator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #676e70;}@property --property-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --operator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f8c49e;}@property --parameter-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f371a6;}@property --var-token-color{syntax: \"<color>\"; inherits: true; initial-value: #cfddd2;}@property --comment-token-color{syntax: \"<color>\"; inherits: true; initial-value: gray;}@property --text-token-color{syntax: \"<color>\"; inherits: true; initial-value: lightgray;}@property --element-token-color{syntax: \"<color>\"; inherits: true; initial-value: salmon;}@property --attribute-color{syntax: \"<color>\"; inherits: true; initial-value: #ffd255;}@property --special-char-token-color{syntax: \"<color>\"; inherits: true; initial-value: #4cdaab;}@property --selector-token-color{syntax: \"<color>\"; inherits: true; initial-value: #daa14c;}@property --prop-token-color{syntax: \"<color>\"; inherits: true; initial-value: #da4cc7;}@property --check-icon-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --copy-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M360-240q-33 0-56.5-23.5T280-320v-480q0-33 23.5-56.5T360-880h360q33 0 56.5 23.5T800-800v480q0 33-23.5 56.5T720-240H360Zm0-80h360v-480H360v480ZM200-80q-33 0-56.5-23.5T120-160v-560h80v560h440v80H200Zm160-240v-480 480Z\";}@property --check-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z\";}*{--_snippet-font: var( --snippet-font, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif );font-family:var(--_snippet-font)}\n/**\n * @license\n * Copyright Slavko Mihajlovic All Rights Reserved.\n *\n * Use of this source code is governed by an ISC-style license that can be\n * found at https://www.isc.org/licenses/\n */\n", ".snippets-content{--_fill-color: var(--snippet-header-text-color);width:inherit;height:inherit;min-height:40px;border-radius:var(--snippet-border-radius);background-color:var(--snippet-background-color);margin:0 auto;overflow:hidden;position:relative;z-index:2}.snippets-content *{background:none}.snippets-content .snippets-header{width:auto;height:auto;display:flex;justify-content:flex-end;background-color:var(--snippet-header-background-color)!important;border-radius:var(--snippet-border-radius) var(--snippet-border-radius) 0 0;font-size:var(--snippets-header-font-size)}.snippets-content .snippets-header .snippet-tab{padding:5px;border-radius:0px 0px var(--snippet-tab-border-radius) var(--snippet-tab-border-radius);color:var(--snippet-header-text-color);cursor:pointer}.snippets-content .snippets-header .snippet-tab:hover{filter:brightness(150%);-webkit-backdrop-filter:brightness(60%);backdrop-filter:brightness(60%)}.snippets-content .snippets-header .active-tab{filter:brightness(150%);-webkit-backdrop-filter:brightness(50%);backdrop-filter:brightness(50%)}.snippets-content .copy-button svg,.snippets-content .snippets-header .copy-tab svg{fill:var(--_fill-color)}.snippets-content .copy-button svg path,.snippets-content .snippets-header .copy-tab svg path{d:path(var(--copy-icon-path))}.snippets-content .copy-button svg:hover,.snippets-content .snippets-header .copy-tab svg:hover{filter:brightness(150%)}.snippets-content .copy-button:active,.snippets-content .snippets-header .copy-tab:active{--copy-icon-path: var(--check-icon-path);--_fill-color: var(--check-icon-color)}.snippets-content .snippets-header .copy-tab svg{height:calc(var(--snippets-header-font-size) - 1px);width:calc(var(--snippets-header-font-size) - 1px)}.snippets-content .copy-button{position:absolute;top:5px;right:5px;display:flex;justify-content:center;align-items:center;background-color:var(--snippet-header-background-color);border-radius:2px;height:calc(var(--snippet-font-size) + 3px);width:calc(var(--snippet-font-size) + 3px)}.snippets-content .copy-button svg{height:calc(var(--snippet-font-size) + 1px);width:calc(var(--snippet-font-size) + 1px)}.snippets-content .snippets-code-lines{min-height:inherit;width:100%;height:100%;border-radius:0 0 var(--snippet-border-radius) var(--snippet-border-radius)}.snippets-content .snippets-code-lines pre{margin:5px 0}.snippets-content .snippets-gutter{display:block;width:var(--snippets-gutter-width);height:100%;min-width:var(--snippets-gutter-width);min-height:inherit;pointer-events:auto;flex-direction:column;align-items:flex-end;color:var(--snippet-header-text-color);padding:5px 0;border-right:1px solid var(--snippet-header-text-color);-webkit-backdrop-filter:brightness(120%);backdrop-filter:brightness(120%)}.snippets-content .snippets-code-lines,.snippets-content .snippets-gutter{font-size:var(--snippet-font-size);letter-spacing:var(--snippet-letter-spacing);height:100%}.snippets-content .selected-line{filter:brightness(130%);background-color:var(--snippet-background-color);-webkit-backdrop-filter:brightness(150%);backdrop-filter:brightness(150%)}.snippets-content .line{display:block;padding-left:10px}.snippets-content .line-focus{-webkit-backdrop-filter:hue-rotate(-25deg);backdrop-filter:hue-rotate(-25deg);border-top:1px solid var(--snippet-header-text-color);border-bottom:1px solid var(--snippet-header-text-color);margin:-1px 0}.snippets-content .snippets{display:flex;flex-direction:row;overflow:auto;min-height:inherit;scrollbar-width:thin;scrollbar-color:var(--snippet-header-text-color) var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar{width:var(--snippets-scrollbar-width);height:var(--snippets-scrollbar-height)}.snippets-content .snippets::-webkit-scrollbar-track{border-radius:2px;background-color:var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar-thumb{border-radius:2px;background-color:var(--snippet-header-text-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: CopyService }], propDecorators: { number: [{
                type: Input
            }] } });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @internal
 * @description
 * A base directive used by both {@link CodeTokenizerDirective} and {@link TemplateTokenizerDirective},
 * responsible, applying  proper styling to the code(mostly coloring), numbering the lines,
 * and handling line focus,
 *
 * For token definition please refer to: https://en.wikipedia.org/wiki/Token#Computing
 */
class CodeHandlerDirective {
    constructor() {
        this.lineCount = 1;
        this.lineNumber = 1;
        this.unListeners = [];
        this.elementRef = inject(ElementRef);
        this.renderer = inject(Renderer2);
        this.copyService = inject(CopyService);
        this.viewContainer = inject(ViewContainerRef);
        this.self = this.elementRef.nativeElement;
        this.createLine();
    }
    /**
     * Tears down every line/listener/counter the directive owns and starts
     * fresh. Required whenever tokens are re-bound — otherwise DOM nodes,
     * click listeners and line numbers accumulate across rebinds.
     */
    reset() {
        this.unListeners.forEach((unListener) => unListener());
        this.unListeners = [];
        while (this.self?.firstChild) {
            this.renderer.removeChild(this.self, this.self.firstChild);
        }
        this.clearNumberLines();
        this.lineCount = 1;
        this.lineNumber = 1;
        this.createLine();
    }
    handleToken(token) {
        if (token.token === `\n`) {
            if (this.runningLine.children.length === 0) {
                this.renderer.setProperty(this.runningLine, 'textContent', `\n`);
            }
            this.createLine();
            this.addNumberLine();
            this.lineNumber++;
        }
        else {
            this.createSpan(token);
        }
    }
    createSpan(token) {
        if (token.token !== `\n` && token.token) {
            const span = this.renderer.createElement('span');
            this.renderer.setProperty(span, 'innerText', token.token);
            this.renderer.addClass(span, token.class);
            this.renderer.appendChild(this.runningLine, span);
        }
    }
    addNumberLine() {
        const numberLine = this.viewContainer.createComponent(NumberLineComponent);
        numberLine.setInput('number', this.lineNumber);
        this.renderer.appendChild(this.lineNumbers, numberLine.location.nativeElement);
    }
    clearNumberLines() {
        while (this.lineNumbers?.firstChild) {
            this.renderer.removeChild(this.lineNumbers, this.lineNumbers.lastChild);
        }
    }
    createLine() {
        this.runningLine = this.renderer.createElement('div');
        this.renderer.setAttribute(this.runningLine, 'row-num', this.lineCount.toString());
        this.renderer.addClass(this.runningLine, 'line');
        this.unListeners.push(this.renderer.listen(this.runningLine, 'click', (event) => this.focus(event)));
        this.renderer.appendChild(this.self, this.runningLine);
        this.lineCount++;
    }
    focus(event) {
        const line = event.target.parentElement;
        if (line && line.hasAttribute('row-num')) {
            if (line.classList.contains('line-focus')) {
                this.renderer.removeClass(line, 'line-focus');
            }
            else {
                this.clearFocus(line);
                this.renderer.addClass(line, 'line-focus');
            }
        }
    }
    clearFocus(element) {
        const parent = element.parentElement;
        const divs = parent?.children;
        if (divs) {
            for (let i = 0; i < divs?.length; i++) {
                this.renderer.removeClass(divs[i], 'line-focus');
            }
        }
    }
    ngOnDestroy() {
        this.unListeners.forEach((unListener) => unListener());
        this.unListeners = [];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CodeHandlerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.21", type: CodeHandlerDirective, isStandalone: true, inputs: { lineNumbers: "lineNumbers" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CodeHandlerDirective, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { lineNumbers: [{
                type: Input
            }] } });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @internal
 * @description
 * A directive responsible for handling snippets passed a snippets input
 * The {@link OmniSnippetsComponent} preforms the token classification and
 * passes the tokens to this directives for further handling
 */
class CodeTokenizerDirective extends CodeHandlerDirective {
    constructor() {
        super(...arguments);
        this.format = 'TypeScript';
    }
    set tokens(tokens) {
        this.reset();
        tokens.forEach((token) => {
            this.handleToken(token);
        });
        this.addNumberLine();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CodeTokenizerDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.21", type: CodeTokenizerDirective, isStandalone: true, selector: "[codeTokenizer]", inputs: { format: "format", tokens: "tokens" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: CodeTokenizerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[codeTokenizer]',
                }]
        }], propDecorators: { format: [{
                type: Input
            }], tokens: [{
                type: Input
            }] } });

const JS_SPLIT = /(["'`\t\n\v\f\r !,.:;{}()\[\]])/g;
const HTML_SPLIT = /([/<>="\t\n\v\f\r ])/g;
const CSS_SPLIT = /(["'\t\n\v\f\r ,:;{}()])/g;
const PYTHON_SPLIT = /(["'\t\n\v\f\r !,.:;{}()\[\]#@])/g;

const QUOTE_CHARS = ['"', "'", '`'];
class BaseTokenizer {
    constructor(commentConfig) {
        /** Char that opened the current string, or null if not inside a string. */
        this.openQuote = null;
        this.commented = false;
        this.comment = false;
        this.commentConfig = commentConfig || {
            commentToken: '//',
        };
    }
    get quoted() {
        return this.openQuote !== null;
    }
    parseAndClassify(text) {
        const tokens = text.split(this.splitExpression);
        const classifiedTokens = [];
        tokens.forEach((token, index) => {
            classifiedTokens.push(this.classifyToken({
                token,
                nextToken: tokens[index + 1],
                priorToken: tokens[index - 1],
                priorPriorToken: tokens[index - 2],
            }));
        });
        return classifiedTokens;
    }
    classifyToken(tokenData) {
        return {
            token: tokenData.token,
            class: this.isQuoted(tokenData) ||
                this.isComment(tokenData) ||
                this.isCommented(tokenData) ||
                this.getClass(tokenData),
        };
    }
    /**
     * Tracks string-literal state. Only the same quote char that opened the
     * string can close it — so `"don't"` stays a single string instead of
     * flipping state on the apostrophe.
     */
    isQuoted(tokenData) {
        const wasQuoted = this.openQuote !== null;
        const ch = tokenData.token;
        if (this.openQuote === null && QUOTE_CHARS.includes(ch)) {
            this.openQuote = ch;
            return 'quoted-token';
        }
        if (this.openQuote !== null && this.openQuote === ch) {
            this.openQuote = null;
            return 'quoted-token';
        }
        return wasQuoted ? 'quoted-token' : undefined;
    }
    isCommented(tokenData) {
        let commentClass;
        if (this.commented) {
            commentClass = 'comment-token';
        }
        if (tokenData.token === this.commentConfig.blockToken?.startToken ||
            tokenData.token === this.commentConfig.blockToken?.endToken) {
            this.commented = !this.commented;
            commentClass = 'comment-token';
        }
        return commentClass;
    }
    isComment(tokenData) {
        let commentClass;
        if (tokenData.token === this.commentConfig.commentToken) {
            this.comment = true;
            commentClass = 'comment-token';
        }
        if (this.comment) {
            if (tokenData.nextToken === `\n`) {
                this.comment = false;
            }
            commentClass = 'comment-token';
        }
        return commentClass;
    }
}

const COMMENT_CONFIG$4 = {
    blockToken: {
        startToken: '!--',
        endToken: '--',
    },
};
class HTMLTokenizer extends BaseTokenizer {
    constructor() {
        super(COMMENT_CONFIG$4);
        this.splitExpression = HTML_SPLIT;
    }
    getClass(tokenData) {
        if (this.isMark(tokenData)) {
            return 'declaration-keyword-token';
        }
        else if (this.isElementName(tokenData)) {
            return 'element-token';
        }
        else if (this.isAttribute(tokenData)) {
            return 'attribute-token';
        }
        else {
            return 'text-token';
        }
    }
    isElementName(tokenData) {
        return ((tokenData.priorToken === '<' || tokenData.priorToken === '/') &&
            (tokenData.nextToken === ' ' || tokenData.nextToken === '>'));
    }
    isAttribute(tokenData) {
        return (tokenData.nextToken === '=' ||
            (tokenData.nextToken === '>' &&
                tokenData.priorToken === ' ' &&
                tokenData.priorPriorToken !== '/'));
    }
    isMark(tokenData) {
        return /[<>=/]/.test(tokenData.token);
    }
}

const CONTROL_KEYWORDS = [
    'abstract',
    'async',
    'await',
    'break',
    'case',
    'catch',
    'delete',
    'else',
    'export',
    'extends',
    'for',
    'from',
    'if',
    'import',
    'instanceof',
    'in',
    'keyof',
    'new',
    'of',
    'return',
    'switch',
    'throw',
    'typeof',
    'try',
];
const CONTEXT_KEYWORDS = [
    'arguments',
    // 'constructor',
    'continue',
    'debugger',
    'default',
    'do',
    'enum ',
    'eval',
    'final',
    'finally',
    'function',
    'goto',
    'native',
    'protected',
    'short',
    'super',
    'synchronized',
    'this',
    'transient',
    'volatile',
    'while',
    'with',
];
const DECLARATION_KEYWORDS = [
    'as',
    'class',
    'const',
    'implements',
    'interface',
    'let',
    'navigator',
    'package',
    'private',
    'public',
    'readonly',
    'static',
    'var',
    'yield',
    'window',
];
const OPERATOR_TOKENS = [
    '=',
    '==',
    '===',
    '>',
    '<',
    '>=',
    '<=',
    '=>',
    '+',
    '++',
    '+=',
    '-',
    '--',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '&&',
    '||',
];
const BOOLEAN_KEYWORDS = ['false', 'true'];
const DATA_TYPE_TOKENS = [
    'boolean',
    'string',
    'number',
    'void',
    'null',
    'never',
    'unknown',
    'any',
];

const COMMENT_CONFIG$3 = {
    commentToken: '//',
    blockToken: {
        startToken: '/**',
        endToken: '*/',
    },
};
class JSTokenizer extends BaseTokenizer {
    constructor() {
        super(COMMENT_CONFIG$3);
        this.splitExpression = JS_SPLIT;
        this.scopeLevelRound = 1;
        this.scopeLevelSquare = 1;
        this.scopeLevelCurly = 1;
    }
    getClass(tokenData) {
        if (this.isSeparatorToken(tokenData)) {
            return 'separator-token';
        }
        else if (tokenData.token === '{') {
            return `scope-level-${this.scopeLevelCurly++}`;
        }
        else if (tokenData.token === '}') {
            return `scope-level-${--this.scopeLevelCurly}`;
        }
        else if (tokenData.token === '(') {
            return `scope-level-${this.scopeLevelRound++}`;
        }
        else if (tokenData.token === ')') {
            return `scope-level-${--this.scopeLevelRound}`;
        }
        else if (tokenData.token === '[') {
            return `scope-level-${this.scopeLevelSquare++}`;
        }
        else if (tokenData.token === ']') {
            return `scope-level-${--this.scopeLevelSquare}`;
        }
        else if (this.isObjectProperty(tokenData)) {
            return 'property-token';
        }
        else if (this.isKeywordToken(tokenData, CONTROL_KEYWORDS)) {
            return 'control-keyword-token';
        }
        else if (this.isKeywordToken(tokenData, CONTEXT_KEYWORDS)) {
            return 'context-keyword-token';
        }
        else if (this.isKeywordToken(tokenData, DECLARATION_KEYWORDS)) {
            return 'declaration-keyword-token';
        }
        else if (this.isDataToken(tokenData)) {
            return 'data-token';
        }
        else if (this.isFunctionToken(tokenData)) {
            return 'function-token';
        }
        else if (this.isParameterToken(tokenData)) {
            return 'parameter-token';
        }
        else if (this.isOperatorToken(tokenData)) {
            return 'operator-token';
        }
        else if (/[()]/.test(tokenData.token)) {
            return 'var-token';
        }
        else {
            return 'text-token';
        }
    }
    isObjectProperty(tokenData) {
        return (tokenData.priorToken === '.' &&
            (tokenData.nextToken === '.' ||
                tokenData.nextToken === ')' ||
                tokenData.nextToken === ',' ||
                !tokenData.nextToken));
    }
    isKeywordToken(tokenData, tokenSet) {
        return (tokenSet.some((token) => token === tokenData.token) &&
            tokenData.nextToken !== ':');
    }
    isDataToken(tokenData) {
        return (!!(tokenData.priorPriorToken === ':' && tokenData.token) ||
            DATA_TYPE_TOKENS.some((token) => token === tokenData.token));
    }
    isFunctionToken(tokenData) {
        return tokenData.nextToken === '(' && !tokenData.token.includes('/');
    }
    isParameterToken(tokenData) {
        return tokenData.nextToken !== ')' && tokenData.nextToken === ':';
    }
    isSeparatorToken(tokenData) {
        return /[!,.:;]/.test(tokenData.token);
    }
    isOperatorToken(tokenData) {
        return OPERATOR_TOKENS.some((token) => token === tokenData.token);
    }
}

const CSS_TOKENS = [
    'absolute',
    'acos',
    'asin',
    'atan',
    'atan2',
    'attr',
    'auto',
    'blur',
    'brightness',
    'calc',
    'circle',
    'clamp',
    'color-mix',
    'color',
    'column',
    'conic-gradient',
    'contrast',
    'cos',
    'counter',
    'counters',
    'cubic-bezier',
    'drop-shadow',
    'ellipse',
    'exp',
    'filter',
    'fit-content',
    'flex-end',
    'flex-start',
    'flex',
    'grayscale',
    'hidden',
    'hsl',
    'hsla',
    'hue-rotate',
    'hwb',
    'hypot',
    'initial',
    'inset',
    'invert',
    'lab',
    'lch',
    'light-dark',
    'linear-gradient',
    'log',
    'matrix',
    'matrix3d',
    'max',
    'min',
    'minmax',
    'mod',
    'oklab',
    'oklch',
    'opacity',
    'perspective',
    'pointer',
    'polygon',
    'pow',
    'radial-gradient',
    'ray',
    'relative',
    'rem',
    'repeat',
    'repeating-conic-gradient',
    'repeating-linear-gradient',
    'repeating-radial-gradient',
    'rgb',
    'rgba',
    'rotate',
    'rotate3d',
    'rotateX',
    'rotateY',
    'rotateZ',
    'round',
    'row',
    'saturate',
    'scale',
    'scale3d',
    'scaleX',
    'scaleY',
    'sepia',
    'sin',
    'skew',
    'skewX',
    'skewY',
    'smooth',
    'solid',
    'sqrt',
    'static',
    'steps',
    'sticky',
    'tan',
    'translate',
    'translateX',
    'translateY',
    'unset',
    'url',
    'var',
    'inherit',
];
const CSS_PROP_TOKENS = [
    '@charset',
    '@container',
    '@counter-style',
    '@font-face',
    '@font-palette-values',
    '@import',
    '@keyframes',
    '@layer',
    '@media',
    '@namespace',
    '@page',
    '@property',
    '@scope',
    '@starting-style',
    '@supports',
    '!important'
];

const HTML_TOKENS = [
    'base',
    'head',
    'link',
    'meta',
    'style',
    'title',
    'body',
    'address',
    'article',
    'aside',
    'footer',
    'header',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'hgroup',
    'main',
    'nav',
    'section',
    'search',
    'blockquote',
    'dd',
    'div',
    'dl',
    'dt',
    'figcaption',
    'figure',
    'hr',
    'li',
    'menu',
    'ol',
    'p',
    'pre',
    'ul',
    'a',
    'abbr',
    'b',
    'bdi',
    'bdo',
    'br',
    'cite',
    'code',
    'data',
    'dfn',
    'em',
    'i',
    'kbd',
    'mark',
    'q',
    'rp',
    'rt',
    'ruby',
    's',
    'samp',
    'small',
    'span',
    'strong',
    'sub',
    'sup',
    'time',
    'u',
    'var',
    'wbr',
    'area',
    'audio',
    'img',
    'map',
    'track',
    'video',
    'embed',
    'fencedframe',
    'iframe',
    'object',
    'picture',
    'source',
    'svg',
    'math',
    'canvas',
    'noscript',
    'script',
    'del',
    'ins',
    'caption',
    'col',
    'colgroup',
    'table',
    'tbody',
    'td',
    'tfoot',
    'th',
    'thead',
    'tr',
    'button',
    'datalist',
    'fieldset',
    'form',
    'input',
    'label',
    'legend',
    'meter',
    'optgroup',
    'option',
    'output',
    'progress',
    'select',
    'textarea',
    'details',
    'dialog',
    'summary',
    'slot',
    'template',
    'acronym',
    'big',
    'center',
    'content',
    'dir',
    'font',
    'frame',
    'frameset',
    'image',
    'marquee',
    'menuitem',
    'nobr',
    'noembed',
    'noframes',
    'param',
    'plaintext',
    'rb',
    'rtc',
    'shadow',
    'strike',
    'tt',
    'xmp',
];

const COMMENT_CONFIG$2 = {
    blockToken: {
        startToken: '/*',
        endToken: '*/',
    },
};
const HEX_COLOR_RE = /^#[0-9a-fA-F]{3,8}$/;
class CSSTokenizer extends BaseTokenizer {
    constructor() {
        super(COMMENT_CONFIG$2);
        this.splitExpression = CSS_SPLIT;
        this.scopeLevelCurly = 1;
        this.scopeLevelRound = 1;
    }
    getClass(tokenData) {
        if (this.isHexColor(tokenData)) {
            return 'data-token';
        }
        else if (this.isSelector(tokenData)) {
            return 'selector-token';
        }
        else if (tokenData.token === '{') {
            return `scope-level-${this.scopeLevelCurly++}`;
        }
        else if (tokenData.token === '}') {
            return `scope-level-${--this.scopeLevelCurly}`;
        }
        else if (tokenData.token === '(') {
            return `scope-level-${this.scopeLevelRound++}`;
        }
        else if (tokenData.token === ')') {
            return `scope-level-${--this.scopeLevelRound}`;
        }
        else if (this.isElementName(tokenData)) {
            return 'element-token';
        }
        else if (this.isDefinition(tokenData)) {
            return 'declaration-keyword-token';
        }
        else if (this.isFunction(tokenData)) {
            return 'function-token';
        }
        else if (this.isProp(tokenData)) {
            return 'css-prop-token';
        }
        else if (this.isSeparatorToken(tokenData)) {
            return 'separator-token';
        }
        else {
            return 'text-token';
        }
    }
    isHexColor(tokenData) {
        return HEX_COLOR_RE.test(tokenData.token);
    }
    isElementName(tokenData) {
        return HTML_TOKENS.includes(tokenData.token) && tokenData.token !== 'var';
    }
    isSelector(tokenData) {
        return (tokenData.nextToken === '{' ||
            tokenData.token.startsWith('.') ||
            tokenData.token.startsWith('#'));
    }
    isDefinition(tokenData) {
        return tokenData.nextToken === ':';
    }
    isFunction(tokenData) {
        return CSS_TOKENS.includes(tokenData.token);
    }
    isProp(tokenData) {
        return CSS_PROP_TOKENS.includes(tokenData.token);
    }
    isSeparatorToken(tokenData) {
        return /([,.:;])/.test(tokenData.token);
    }
}

const JSON_LITERAL_TOKENS = ['true', 'false', 'null'];

const NUMBER_RE$2 = /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/;
/**
 * JSON has no comments and only three literal keywords (true, false, null).
 * Keys are quoted strings followed by `:`, values are quoted strings,
 * numbers, literals, arrays, or objects.
 */
class JSONTokenizer extends BaseTokenizer {
    constructor() {
        super({ commentToken: undefined });
        this.splitExpression = JS_SPLIT;
        this.scopeLevelCurly = 1;
        this.scopeLevelSquare = 1;
    }
    getClass(tokenData) {
        if (tokenData.token === '{') {
            return `scope-level-${this.scopeLevelCurly++}`;
        }
        else if (tokenData.token === '}') {
            return `scope-level-${--this.scopeLevelCurly}`;
        }
        else if (tokenData.token === '[') {
            return `scope-level-${this.scopeLevelSquare++}`;
        }
        else if (tokenData.token === ']') {
            return `scope-level-${--this.scopeLevelSquare}`;
        }
        else if (this.isLiteral(tokenData)) {
            return 'declaration-keyword-token';
        }
        else if (this.isNumber(tokenData)) {
            return 'data-token';
        }
        else if (this.isKey(tokenData)) {
            return 'property-token';
        }
        else if (this.isSeparator(tokenData)) {
            return 'separator-token';
        }
        else {
            return 'text-token';
        }
    }
    isLiteral(tokenData) {
        return JSON_LITERAL_TOKENS.includes(tokenData.token);
    }
    isNumber(tokenData) {
        return NUMBER_RE$2.test(tokenData.token);
    }
    isKey(tokenData) {
        return tokenData.nextToken === ':';
    }
    isSeparator(tokenData) {
        return /[,:]/.test(tokenData.token);
    }
}

const PYTHON_CONTROL_KEYWORDS = [
    'break',
    'continue',
    'elif',
    'else',
    'except',
    'finally',
    'for',
    'from',
    'if',
    'import',
    'pass',
    'raise',
    'return',
    'try',
    'while',
    'with',
    'yield',
];
const PYTHON_CONTEXT_KEYWORDS = [
    'async',
    'await',
    'class',
    'def',
    'global',
    'lambda',
    'nonlocal',
];
const PYTHON_DECLARATION_KEYWORDS = [
    'and',
    'as',
    'assert',
    'del',
    'in',
    'is',
    'not',
    'or',
    'match',
    'case',
];
const PYTHON_DATA_TYPES = [
    'bool',
    'bytearray',
    'bytes',
    'complex',
    'dict',
    'float',
    'frozenset',
    'int',
    'list',
    'object',
    'set',
    'str',
    'tuple',
    'type',
    'None',
    'True',
    'False',
];

const COMMENT_CONFIG$1 = {
    commentToken: '#',
};
const NUMBER_RE$1 = /^-?\d+(\.\d+)?([eE][+-]?\d+)?[jJ]?$/;
/**
 * Python uses indentation for scope (no curly braces), `#` for line comments,
 * and `@` for decorators. Triple-quoted strings rely on the base quote state
 * machine — perfect multi-line docstring highlighting is out of scope for a
 * snippet renderer.
 */
class PythonTokenizer extends BaseTokenizer {
    constructor() {
        super(COMMENT_CONFIG$1);
        this.splitExpression = PYTHON_SPLIT;
        this.scopeLevelRound = 1;
        this.scopeLevelSquare = 1;
        this.scopeLevelCurly = 1;
    }
    getClass(tokenData) {
        if (this.isSeparator(tokenData)) {
            return 'separator-token';
        }
        else if (tokenData.token === '{') {
            return `scope-level-${this.scopeLevelCurly++}`;
        }
        else if (tokenData.token === '}') {
            return `scope-level-${--this.scopeLevelCurly}`;
        }
        else if (tokenData.token === '(') {
            return `scope-level-${this.scopeLevelRound++}`;
        }
        else if (tokenData.token === ')') {
            return `scope-level-${--this.scopeLevelRound}`;
        }
        else if (tokenData.token === '[') {
            return `scope-level-${this.scopeLevelSquare++}`;
        }
        else if (tokenData.token === ']') {
            return `scope-level-${--this.scopeLevelSquare}`;
        }
        else if (this.isDecorator(tokenData)) {
            return 'context-keyword-token';
        }
        else if (this.isKeyword(tokenData, PYTHON_CONTROL_KEYWORDS)) {
            return 'control-keyword-token';
        }
        else if (this.isKeyword(tokenData, PYTHON_CONTEXT_KEYWORDS)) {
            return 'context-keyword-token';
        }
        else if (this.isKeyword(tokenData, PYTHON_DECLARATION_KEYWORDS)) {
            return 'declaration-keyword-token';
        }
        else if (this.isDataType(tokenData)) {
            return 'data-token';
        }
        else if (this.isNumber(tokenData)) {
            return 'data-token';
        }
        else if (this.isFunction(tokenData)) {
            return 'function-token';
        }
        else {
            return 'text-token';
        }
    }
    isKeyword(tokenData, tokenSet) {
        return tokenSet.includes(tokenData.token);
    }
    isDataType(tokenData) {
        return PYTHON_DATA_TYPES.includes(tokenData.token);
    }
    isFunction(tokenData) {
        return tokenData.nextToken === '(' && tokenData.token.length > 0;
    }
    isDecorator(tokenData) {
        return tokenData.token === '@' || tokenData.priorToken === '@';
    }
    isNumber(tokenData) {
        return NUMBER_RE$1.test(tokenData.token);
    }
    isSeparator(tokenData) {
        return /[,.:;]/.test(tokenData.token);
    }
}

/**
 * SQL is case-insensitive — these lists are stored lowercase. Matching
 * happens against `token.toLowerCase()` so `SELECT`, `select`, and `Select`
 * all classify the same.
 */
const SQL_CONTROL_KEYWORDS = [
    'select',
    'from',
    'where',
    'join',
    'inner',
    'outer',
    'left',
    'right',
    'full',
    'cross',
    'on',
    'using',
    'group',
    'by',
    'order',
    'having',
    'limit',
    'offset',
    'union',
    'intersect',
    'except',
    'with',
    'returning',
    'values',
    'into',
    'set',
];
const SQL_CONTEXT_KEYWORDS = [
    'insert',
    'update',
    'delete',
    'create',
    'drop',
    'alter',
    'truncate',
    'rename',
    'replace',
    'merge',
    'grant',
    'revoke',
    'begin',
    'commit',
    'rollback',
    'savepoint',
];
const SQL_DECLARATION_KEYWORDS = [
    'as',
    'asc',
    'desc',
    'distinct',
    'all',
    'any',
    'some',
    'and',
    'or',
    'not',
    'in',
    'between',
    'like',
    'ilike',
    'is',
    'null',
    'exists',
    'case',
    'when',
    'then',
    'else',
    'end',
    'if',
    'while',
    'loop',
    'declare',
    'cursor',
    'fetch',
    'open',
    'close',
    'table',
    'view',
    'index',
    'database',
    'schema',
    'column',
    'constraint',
    'primary',
    'foreign',
    'key',
    'references',
    'default',
    'check',
    'unique',
    'cascade',
    'restrict',
];
const SQL_DATA_TYPES = [
    'int',
    'integer',
    'smallint',
    'bigint',
    'tinyint',
    'decimal',
    'numeric',
    'real',
    'double',
    'float',
    'money',
    'char',
    'varchar',
    'nchar',
    'nvarchar',
    'text',
    'ntext',
    'date',
    'datetime',
    'datetime2',
    'time',
    'timestamp',
    'timestamptz',
    'interval',
    'bit',
    'boolean',
    'bool',
    'binary',
    'varbinary',
    'blob',
    'json',
    'jsonb',
    'uuid',
    'serial',
    'bigserial',
];
const SQL_OPERATORS = [
    '=',
    '<>',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '+',
    '-',
    '*',
    '/',
    '%',
    '||',
];

const COMMENT_CONFIG = {
    commentToken: '--',
    blockToken: {
        startToken: '/*',
        endToken: '*/',
    },
};
const NUMBER_RE = /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/;
/**
 * SQL is case-insensitive — keyword/datatype matching lowercases the token
 * before comparing against the (lowercase) reference lists.
 */
class SQLTokenizer extends BaseTokenizer {
    constructor() {
        super(COMMENT_CONFIG);
        this.splitExpression = JS_SPLIT;
        this.scopeLevelRound = 1;
    }
    getClass(tokenData) {
        if (this.isSeparator(tokenData)) {
            return 'separator-token';
        }
        else if (tokenData.token === '(') {
            return `scope-level-${this.scopeLevelRound++}`;
        }
        else if (tokenData.token === ')') {
            return `scope-level-${--this.scopeLevelRound}`;
        }
        else if (this.isNumber(tokenData)) {
            return 'data-token';
        }
        else if (this.isKeyword(tokenData, SQL_CONTROL_KEYWORDS)) {
            return 'control-keyword-token';
        }
        else if (this.isKeyword(tokenData, SQL_CONTEXT_KEYWORDS)) {
            return 'context-keyword-token';
        }
        else if (this.isKeyword(tokenData, SQL_DECLARATION_KEYWORDS)) {
            return 'declaration-keyword-token';
        }
        else if (this.isDataType(tokenData)) {
            return 'data-token';
        }
        else if (this.isFunction(tokenData)) {
            return 'function-token';
        }
        else if (this.isOperator(tokenData)) {
            return 'operator-token';
        }
        else {
            return 'text-token';
        }
    }
    isKeyword(tokenData, tokenSet) {
        return tokenSet.includes(tokenData.token.toLowerCase());
    }
    isDataType(tokenData) {
        return SQL_DATA_TYPES.includes(tokenData.token.toLowerCase());
    }
    isFunction(tokenData) {
        return tokenData.nextToken === '(' && tokenData.token.length > 0;
    }
    isOperator(tokenData) {
        return SQL_OPERATORS.includes(tokenData.token);
    }
    isNumber(tokenData) {
        return NUMBER_RE.test(tokenData.token);
    }
    isSeparator(tokenData) {
        return /[,.;]/.test(tokenData.token);
    }
}

const DEFAULT_C_STYLE_COMMENT = {
    commentToken: '//',
    blockToken: {
        startToken: '/**',
        endToken: '*/',
    },
};
class CStyleTokenizer extends BaseTokenizer {
    constructor(config) {
        super(config.commentConfig ?? DEFAULT_C_STYLE_COMMENT);
        this.scopeLevelRound = 1;
        this.scopeLevelSquare = 1;
        this.scopeLevelCurly = 1;
        this.config = config;
        this.splitExpression = config.splitExpression ?? JS_SPLIT;
    }
    getClass(tokenData) {
        if (this.isSeparatorToken(tokenData)) {
            return 'separator-token';
        }
        else if (tokenData.token === '{') {
            return `scope-level-${this.scopeLevelCurly++}`;
        }
        else if (tokenData.token === '}') {
            return `scope-level-${--this.scopeLevelCurly}`;
        }
        else if (tokenData.token === '(') {
            return `scope-level-${this.scopeLevelRound++}`;
        }
        else if (tokenData.token === ')') {
            return `scope-level-${--this.scopeLevelRound}`;
        }
        else if (tokenData.token === '[') {
            return `scope-level-${this.scopeLevelSquare++}`;
        }
        else if (tokenData.token === ']') {
            return `scope-level-${--this.scopeLevelSquare}`;
        }
        else if (this.isObjectProperty(tokenData)) {
            return 'property-token';
        }
        else if (this.isKeywordToken(tokenData, this.config.controlKeywords)) {
            return 'control-keyword-token';
        }
        else if (this.isKeywordToken(tokenData, this.config.contextKeywords)) {
            return 'context-keyword-token';
        }
        else if (this.isKeywordToken(tokenData, this.config.declarationKeywords)) {
            return 'declaration-keyword-token';
        }
        else if (this.isDataToken(tokenData)) {
            return 'data-token';
        }
        else if (this.isFunctionToken(tokenData)) {
            return 'function-token';
        }
        else if (this.isParameterToken(tokenData)) {
            return 'parameter-token';
        }
        else if (this.isOperatorToken(tokenData)) {
            return 'operator-token';
        }
        else if (/[()]/.test(tokenData.token)) {
            return 'var-token';
        }
        else {
            return 'text-token';
        }
    }
    isObjectProperty(tokenData) {
        return (tokenData.priorToken === '.' &&
            (tokenData.nextToken === '.' ||
                tokenData.nextToken === ')' ||
                tokenData.nextToken === ',' ||
                !tokenData.nextToken));
    }
    isKeywordToken(tokenData, tokenSet) {
        return tokenSet.includes(tokenData.token) && tokenData.nextToken !== ':';
    }
    isDataToken(tokenData) {
        return (!!(tokenData.priorPriorToken === ':' && tokenData.token) ||
            this.config.dataTypes.includes(tokenData.token));
    }
    isFunctionToken(tokenData) {
        return tokenData.nextToken === '(' && !tokenData.token.includes('/');
    }
    isParameterToken(tokenData) {
        return tokenData.nextToken !== ')' && tokenData.nextToken === ':';
    }
    isSeparatorToken(tokenData) {
        return /[!,.:;]/.test(tokenData.token);
    }
    isOperatorToken(tokenData) {
        return this.config.operators.includes(tokenData.token);
    }
}

const JAVA_CONTROL_KEYWORDS = [
    'assert',
    'break',
    'case',
    'catch',
    'continue',
    'do',
    'else',
    'export',
    'extends',
    'finally',
    'for',
    'if',
    'import',
    'instanceof',
    'new',
    'return',
    'switch',
    'throw',
    'throws',
    'try',
    'while',
    'yield',
];
const JAVA_CONTEXT_KEYWORDS = [
    'abstract',
    'default',
    'final',
    'native',
    'package',
    'private',
    'protected',
    'public',
    'static',
    'strictfp',
    'super',
    'synchronized',
    'this',
    'transient',
    'volatile',
];
const JAVA_DECLARATION_KEYWORDS = [
    'class',
    'enum',
    'implements',
    'interface',
    'module',
    'record',
    'sealed',
    'var',
];
const JAVA_DATA_TYPES = [
    'boolean',
    'byte',
    'char',
    'double',
    'float',
    'int',
    'long',
    'short',
    'void',
    'null',
    'Boolean',
    'Byte',
    'Character',
    'Double',
    'Float',
    'Integer',
    'Long',
    'Short',
    'String',
    'Object',
];
const JAVA_OPERATORS = [
    '=',
    '==',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '+',
    '++',
    '+=',
    '-',
    '--',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '%',
    '%=',
    '&&',
    '||',
    '!',
    '&',
    '|',
    '^',
    '~',
    '<<',
    '>>',
    '>>>',
];

class JavaTokenizer extends CStyleTokenizer {
    constructor() {
        super({
            controlKeywords: JAVA_CONTROL_KEYWORDS,
            contextKeywords: JAVA_CONTEXT_KEYWORDS,
            declarationKeywords: JAVA_DECLARATION_KEYWORDS,
            dataTypes: JAVA_DATA_TYPES,
            operators: JAVA_OPERATORS,
        });
    }
}

const CSHARP_CONTROL_KEYWORDS = [
    'await',
    'break',
    'case',
    'catch',
    'checked',
    'continue',
    'do',
    'else',
    'finally',
    'for',
    'foreach',
    'goto',
    'if',
    'in',
    'is',
    'lock',
    'new',
    'out',
    'ref',
    'return',
    'switch',
    'throw',
    'try',
    'unchecked',
    'using',
    'when',
    'where',
    'while',
    'yield',
];
const CSHARP_CONTEXT_KEYWORDS = [
    'abstract',
    'as',
    'async',
    'base',
    'const',
    'default',
    'event',
    'extern',
    'fixed',
    'internal',
    'override',
    'params',
    'partial',
    'private',
    'protected',
    'public',
    'readonly',
    'sealed',
    'static',
    'this',
    'unsafe',
    'virtual',
    'volatile',
];
const CSHARP_DECLARATION_KEYWORDS = [
    'class',
    'delegate',
    'enum',
    'implicit',
    'interface',
    'namespace',
    'operator',
    'record',
    'struct',
    'var',
];
const CSHARP_DATA_TYPES = [
    'bool',
    'byte',
    'sbyte',
    'char',
    'decimal',
    'double',
    'float',
    'int',
    'uint',
    'long',
    'ulong',
    'object',
    'short',
    'ushort',
    'string',
    'void',
    'null',
    'dynamic',
    'nint',
    'nuint',
];
const CSHARP_OPERATORS = [
    '=',
    '==',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '=>',
    '+',
    '++',
    '+=',
    '-',
    '--',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '%',
    '%=',
    '&&',
    '||',
    '!',
    '&',
    '|',
    '^',
    '~',
    '<<',
    '>>',
    '??',
    '?.',
];

class CSharpTokenizer extends CStyleTokenizer {
    constructor() {
        super({
            controlKeywords: CSHARP_CONTROL_KEYWORDS,
            contextKeywords: CSHARP_CONTEXT_KEYWORDS,
            declarationKeywords: CSHARP_DECLARATION_KEYWORDS,
            dataTypes: CSHARP_DATA_TYPES,
            operators: CSHARP_OPERATORS,
        });
    }
}

const GO_CONTROL_KEYWORDS = [
    'break',
    'case',
    'continue',
    'default',
    'defer',
    'else',
    'fallthrough',
    'for',
    'go',
    'goto',
    'if',
    'import',
    'range',
    'return',
    'select',
    'switch',
];
const GO_CONTEXT_KEYWORDS = [
    'chan',
    'const',
    'func',
    'map',
    'package',
    'var',
];
const GO_DECLARATION_KEYWORDS = [
    'interface',
    'struct',
    'type',
];
const GO_DATA_TYPES = [
    'bool',
    'byte',
    'complex64',
    'complex128',
    'error',
    'float32',
    'float64',
    'int',
    'int8',
    'int16',
    'int32',
    'int64',
    'rune',
    'string',
    'uint',
    'uint8',
    'uint16',
    'uint32',
    'uint64',
    'uintptr',
    'nil',
    'true',
    'false',
];
const GO_OPERATORS = [
    '=',
    ':=',
    '==',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '+',
    '++',
    '+=',
    '-',
    '--',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '%',
    '%=',
    '&&',
    '||',
    '!',
    '&',
    '|',
    '^',
    '<<',
    '>>',
    '<-',
];

class GoTokenizer extends CStyleTokenizer {
    constructor() {
        super({
            controlKeywords: GO_CONTROL_KEYWORDS,
            contextKeywords: GO_CONTEXT_KEYWORDS,
            declarationKeywords: GO_DECLARATION_KEYWORDS,
            dataTypes: GO_DATA_TYPES,
            operators: GO_OPERATORS,
        });
    }
}

const RUST_CONTROL_KEYWORDS = [
    'as',
    'async',
    'await',
    'break',
    'continue',
    'do',
    'dyn',
    'else',
    'extern',
    'for',
    'if',
    'in',
    'loop',
    'match',
    'move',
    'return',
    'try',
    'use',
    'where',
    'while',
    'yield',
];
const RUST_CONTEXT_KEYWORDS = [
    'box',
    'crate',
    'const',
    'final',
    'macro',
    'override',
    'priv',
    'pub',
    'ref',
    'self',
    'Self',
    'static',
    'super',
    'unsafe',
    'virtual',
];
const RUST_DECLARATION_KEYWORDS = [
    'enum',
    'fn',
    'impl',
    'let',
    'mod',
    'mut',
    'struct',
    'trait',
    'type',
    'union',
];
const RUST_DATA_TYPES = [
    'bool',
    'char',
    'f32',
    'f64',
    'i8',
    'i16',
    'i32',
    'i64',
    'i128',
    'isize',
    'str',
    'u8',
    'u16',
    'u32',
    'u64',
    'u128',
    'usize',
    'String',
    'Vec',
    'Option',
    'Result',
    'Box',
    'Rc',
    'Arc',
    'None',
    'Some',
    'Ok',
    'Err',
    'true',
    'false',
];
const RUST_OPERATORS = [
    '=',
    '==',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '=>',
    '+',
    '+=',
    '-',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '%',
    '%=',
    '&&',
    '||',
    '!',
    '&',
    '|',
    '^',
    '<<',
    '>>',
    '..',
    '..=',
    '->',
];

class RustTokenizer extends CStyleTokenizer {
    constructor() {
        super({
            controlKeywords: RUST_CONTROL_KEYWORDS,
            contextKeywords: RUST_CONTEXT_KEYWORDS,
            declarationKeywords: RUST_DECLARATION_KEYWORDS,
            dataTypes: RUST_DATA_TYPES,
            operators: RUST_OPERATORS,
        });
    }
}

const CPP_CONTROL_KEYWORDS = [
    'break',
    'case',
    'catch',
    'continue',
    'do',
    'else',
    'export',
    'extern',
    'for',
    'goto',
    'if',
    'import',
    'module',
    'new',
    'return',
    'switch',
    'throw',
    'try',
    'using',
    'while',
];
const CPP_CONTEXT_KEYWORDS = [
    'auto',
    'constexpr',
    'consteval',
    'constinit',
    'default',
    'explicit',
    'export',
    'extern',
    'final',
    'friend',
    'inline',
    'mutable',
    'override',
    'private',
    'protected',
    'public',
    'register',
    'sizeof',
    'static',
    'static_assert',
    'static_cast',
    'thread_local',
    'this',
    'typeid',
    'typename',
    'virtual',
    'volatile',
];
const CPP_DECLARATION_KEYWORDS = [
    'class',
    'concept',
    'const',
    'enum',
    'namespace',
    'operator',
    'requires',
    'struct',
    'template',
    'typedef',
    'union',
];
const CPP_DATA_TYPES = [
    'bool',
    'char',
    'char8_t',
    'char16_t',
    'char32_t',
    'double',
    'float',
    'int',
    'long',
    'short',
    'signed',
    'size_t',
    'unsigned',
    'void',
    'wchar_t',
    'nullptr',
    'NULL',
    'true',
    'false',
];
const CPP_OPERATORS = [
    '=',
    '==',
    '!=',
    '>',
    '<',
    '>=',
    '<=',
    '+',
    '++',
    '+=',
    '-',
    '--',
    '-=',
    '*',
    '*=',
    '/',
    '/=',
    '%',
    '%=',
    '&&',
    '||',
    '!',
    '&',
    '|',
    '^',
    '~',
    '<<',
    '>>',
    '->',
    '::',
];

/**
 * Single tokenizer that serves both `'C'` and `'C++'` formats — C++ keyword
 * set is a superset of C so it lights up correctly for either input.
 */
class CppTokenizer extends CStyleTokenizer {
    constructor() {
        super({
            controlKeywords: CPP_CONTROL_KEYWORDS,
            contextKeywords: CPP_CONTEXT_KEYWORDS,
            declarationKeywords: CPP_DECLARATION_KEYWORDS,
            dataTypes: CPP_DATA_TYPES,
            operators: CPP_OPERATORS,
        });
    }
}

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
class TokenizerService {
    constructor() {
        this.formatterMap = new Map([
            ['TypeScript', JSTokenizer],
            ['JavaScript', JSTokenizer],
            ['HTML', HTMLTokenizer],
            ['CSS', CSSTokenizer],
            ['JSON', JSONTokenizer],
            ['Python', PythonTokenizer],
            ['SQL', SQLTokenizer],
            ['Java', JavaTokenizer],
            ['C#', CSharpTokenizer],
            ['Go', GoTokenizer],
            ['Rust', RustTokenizer],
            ['C', CppTokenizer],
            ['C++', CppTokenizer],
        ]);
    }
    tokenize(text, format) {
        const tokenizer = this.formatterMap.get(format) ?? JSTokenizer;
        return new tokenizer().parseAndClassify(text.trim());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: TokenizerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: TokenizerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: TokenizerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @internal
 * @description
 * A directive responsible for handling snippets passed through an ng-template
 *
 * For more information on ng-template please visit: https://angular.dev/api/core/ng-template
 */
class TemplateTokenizerDirective extends CodeHandlerDirective {
    constructor() {
        super(...arguments);
        this.classifiedTokens = [];
        this.tokenizerService = inject(TokenizerService);
    }
    ngAfterViewInit() {
        this.classifiedTokens = this.tokenizerService.tokenize(this.self.innerText, this.format);
        this.self.innerText = '';
        this.classifiedTokens.forEach((token) => {
            this.handleToken(token);
        });
        this.addNumberLine();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: TemplateTokenizerDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.21", type: TemplateTokenizerDirective, isStandalone: true, selector: "[templateTokenizer]", inputs: { format: "format" }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: TemplateTokenizerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[templateTokenizer]',
                }]
        }], propDecorators: { format: [{
                type: Input
            }] } });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
class RecordForCopyDirective {
    constructor(copyService, elementRef) {
        this.copyService = copyService;
        this.elementRef = elementRef;
        this.self = this.elementRef.nativeElement;
    }
    ngAfterViewInit() {
        this.copyService.set(this.self.innerText);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: RecordForCopyDirective, deps: [{ token: CopyService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.21", type: RecordForCopyDirective, isStandalone: true, selector: "[recordForCopy]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: RecordForCopyDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[recordForCopy]',
                }]
        }], ctorParameters: () => [{ type: CopyService }, { type: i0.ElementRef }] });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @publicApi
 * @description
 * The main component of the library, the actually snippets are being shown from this
 * components view.
 *
 * @usageNotes
 * <omni-snippets
 *  [snippets]="exampleSnippets"  -{@link SnippetConfig}
 *  backlight="backlight-Green"   -{@link Backlights}  effect applied to the snippet
 * ></omni-snippets>
 */
class OmniSnippetsComponent {
    constructor(tokenizerService, copyService) {
        this.tokenizerService = tokenizerService;
        this.copyService = copyService;
        this.tab = 'TypeScript';
        this.classifiedTokens = [];
        this.format = 'JavaScript';
        this.header = true;
    }
    set snippets(snippets) {
        this._snippets = snippets;
        this.classifiedTokens = [];
        if (!snippets || snippets.length === 0) {
            return;
        }
        this.tab = snippets[0].format;
        this.copyService.set(snippets[0].template);
        snippets.forEach((snippet) => {
            this.classifiedTokens.push(this.tokenizerService.tokenize(snippet.template, snippet.format));
        });
    }
    switchSnippet(tab, i) {
        this.tab = tab;
        this.copyService.set(this._snippets[i].template);
    }
    copySnippet() {
        void this.copyService.toClipboard();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: OmniSnippetsComponent, deps: [{ token: TokenizerService }, { token: CopyService, host: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.21", type: OmniSnippetsComponent, isStandalone: true, selector: "omni-snippets", inputs: { backlight: "backlight", neon: "neon", format: "format", header: "header", snippets: "snippets" }, providers: [CopyService], queries: [{ propertyName: "template", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<div [ngClass]=\"{\r\n    'backlight-rgb': backlight === 'backlight-RGB',\r\n    'backlight-blue': backlight === 'backlight-Blue',\r\n    'backlight-orange': backlight === 'backlight-Orange',\r\n    'backlight-green': backlight === 'backlight-Green',\r\n    'backlight-red': backlight === 'backlight-Red'\r\n  }\">\r\n  <div class=\"snippets-content\">\r\n    <div class=\"snippets-header\" *ngIf=\"header; else copyBlock\">\r\n      <div *ngFor=\"let snippet of _snippets; let i = index\">\r\n        <div class=\"snippet-tab\" [ngClass]=\"{\r\n            'active-tab': tab === snippet.format\r\n          }\" (click)=\"switchSnippet(snippet.format, i)\">\r\n          {{ snippet.format }}\r\n        </div>\r\n      </div>\r\n      <div class=\"snippet-tab copy-tab\" (click)=\"copySnippet()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\">\r\n          <path />\r\n        </svg>\r\n      </div>\r\n    </div>\r\n    <ng-template #copyBlock>\r\n      <div class=\"copy-button\" (click)=\"copySnippet()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\">\r\n          <path />\r\n        </svg>\r\n      </div>\r\n    </ng-template>\r\n    <div class=\"snippets\" *ngIf=\"_snippets; else templateBlock\">\r\n      <div\r\n        class=\"snippets-gutter\"\r\n        [ngClass]=\"{\r\n          'gutter-neon-blue': neon === 'neon-Blue',\r\n          'gutter-neon-green': neon === 'neon-Green',\r\n          'gutter-neon-red': neon === 'neon-Red',\r\n          'gutter-neon-orange': neon === 'neon-Orange'\r\n        }\"\r\n        #lineNumbers></div>\r\n      <div\r\n        class=\"snippets-code-lines\"\r\n        [ngClass]=\"{\r\n          'header-neon-blue': neon === 'neon-Blue',\r\n          'header-neon-green': neon === 'neon-Green',\r\n          'header-neon-red': neon === 'neon-Red',\r\n          'header-neon-orange': neon === 'neon-Orange'\r\n        }\">\r\n        <div *ngIf=\"_snippets?.length\">\r\n          <div *ngFor=\"let snippet of _snippets; let i = index\" [ngSwitch]=\"snippet.format\">\r\n            <pre codeTokenizer [lineNumbers]=\"lineNumbers\" [format]=\"snippet.format\" [tokens]=\"classifiedTokens[i]\"\r\n              *ngSwitchCase=\"tab\"></pre>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <ng-template #templateBlock>\r\n      <div class=\"snippets\">\r\n        <div\r\n          class=\"snippets-gutter\"\r\n          [ngClass]=\"{\r\n            'gutter-neon-blue': neon === 'neon-Blue',\r\n            'gutter-neon-green': neon === 'neon-Green',\r\n            'gutter-neon-red': neon === 'neon-Red',\r\n            'gutter-neon-orange': neon === 'neon-Orange'\r\n          }\"\r\n          #lineNumbers></div>\r\n        <div\r\n          class=\"snippets-code-lines\"\r\n          [ngClass]=\"{\r\n            'header-neon-blue': neon === 'neon-Blue',\r\n            'header-neon-green': neon === 'neon-Green',\r\n            'header-neon-red': neon === 'neon-Red',\r\n            'header-neon-orange': neon === 'neon-Orange'\r\n          }\">\r\n          <pre recordForCopy templateTokenizer [lineNumbers]=\"lineNumbers\">\r\n            <ng-container *ngTemplateOutlet=\"template\"></ng-container>\r\n          </pre>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </div>\r\n</div>\r\n", styles: [".snippets-content{--_fill-color: var(--snippet-header-text-color);width:inherit;height:inherit;min-height:40px;border-radius:var(--snippet-border-radius);background-color:var(--snippet-background-color);margin:0 auto;overflow:hidden;position:relative;z-index:2}.snippets-content *{background:none}.snippets-content .snippets-header{width:auto;height:auto;display:flex;justify-content:flex-end;background-color:var(--snippet-header-background-color)!important;border-radius:var(--snippet-border-radius) var(--snippet-border-radius) 0 0;font-size:var(--snippets-header-font-size)}.snippets-content .snippets-header .snippet-tab{padding:5px;border-radius:0px 0px var(--snippet-tab-border-radius) var(--snippet-tab-border-radius);color:var(--snippet-header-text-color);cursor:pointer}.snippets-content .snippets-header .snippet-tab:hover{filter:brightness(150%);-webkit-backdrop-filter:brightness(60%);backdrop-filter:brightness(60%)}.snippets-content .snippets-header .active-tab{filter:brightness(150%);-webkit-backdrop-filter:brightness(50%);backdrop-filter:brightness(50%)}.snippets-content .copy-button svg,.snippets-content .snippets-header .copy-tab svg{fill:var(--_fill-color)}.snippets-content .copy-button svg path,.snippets-content .snippets-header .copy-tab svg path{d:path(var(--copy-icon-path))}.snippets-content .copy-button svg:hover,.snippets-content .snippets-header .copy-tab svg:hover{filter:brightness(150%)}.snippets-content .copy-button:active,.snippets-content .snippets-header .copy-tab:active{--copy-icon-path: var(--check-icon-path);--_fill-color: var(--check-icon-color)}.snippets-content .snippets-header .copy-tab svg{height:calc(var(--snippets-header-font-size) - 1px);width:calc(var(--snippets-header-font-size) - 1px)}.snippets-content .copy-button{position:absolute;top:5px;right:5px;display:flex;justify-content:center;align-items:center;background-color:var(--snippet-header-background-color);border-radius:2px;height:calc(var(--snippet-font-size) + 3px);width:calc(var(--snippet-font-size) + 3px)}.snippets-content .copy-button svg{height:calc(var(--snippet-font-size) + 1px);width:calc(var(--snippet-font-size) + 1px)}.snippets-content .snippets-code-lines{min-height:inherit;width:100%;height:100%;border-radius:0 0 var(--snippet-border-radius) var(--snippet-border-radius)}.snippets-content .snippets-code-lines pre{margin:5px 0}.snippets-content .snippets-gutter{display:block;width:var(--snippets-gutter-width);height:100%;min-width:var(--snippets-gutter-width);min-height:inherit;pointer-events:auto;flex-direction:column;align-items:flex-end;color:var(--snippet-header-text-color);padding:5px 0;border-right:1px solid var(--snippet-header-text-color);-webkit-backdrop-filter:brightness(120%);backdrop-filter:brightness(120%)}.snippets-content .snippets-code-lines,.snippets-content .snippets-gutter{font-size:var(--snippet-font-size);letter-spacing:var(--snippet-letter-spacing);height:100%}.snippets-content .selected-line{filter:brightness(130%);background-color:var(--snippet-background-color);-webkit-backdrop-filter:brightness(150%);backdrop-filter:brightness(150%)}.snippets-content .line{display:block;padding-left:10px}.snippets-content .line-focus{-webkit-backdrop-filter:hue-rotate(-25deg);backdrop-filter:hue-rotate(-25deg);border-top:1px solid var(--snippet-header-text-color);border-bottom:1px solid var(--snippet-header-text-color);margin:-1px 0}.snippets-content .snippets{display:flex;flex-direction:row;overflow:auto;min-height:inherit;scrollbar-width:thin;scrollbar-color:var(--snippet-header-text-color) var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar{width:var(--snippets-scrollbar-width);height:var(--snippets-scrollbar-height)}.snippets-content .snippets::-webkit-scrollbar-track{border-radius:2px;background-color:var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar-thumb{border-radius:2px;background-color:var(--snippet-header-text-color)}\n", "@property --snippet-font-size{syntax: \"<length>\"; inherits: true; initial-value: 13px;}@property --snippets-header-font-size{syntax: \"<length>\"; inherits: true; initial-value: 12px;}@property --snippet-letter-spacing{syntax: \"<length>\"; inherits: true; initial-value: 1px;}@property --snippet-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 5px;}@property --snippet-tab-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 2px;}@property --snippets-gutter-width{syntax: \"<length>\"; inherits: true; initial-value: 72px;}@property --snippets-scrollbar-width{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippets-scrollbar-height{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippet-background-color{syntax: \"<color>\"; inherits: true; initial-value: #202836;}@property --snippet-header-background-color{syntax: \"<color>\"; inherits: true; initial-value: #1a212b;}@property --snippet-header-text-color{syntax: \"<color>\"; inherits: true; initial-value: #61789e;}@property --number-line-highlight-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --number-line-hover-color{syntax: \"<color>\"; inherits: true; initial-value: #07cc8a;}@property --control-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #e1955d;}@property --context-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --declaration-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #22e2b8;}@property --quoted-token-color{syntax: \"<color>\"; inherits: true; initial-value: #34ec71;}@property --data-token-color{syntax: \"<color>\"; inherits: true; initial-value: #a98adf;}@property --function-token-color{syntax: \"<color>\"; inherits: true; initial-value: #44b7ff;}@property --separator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #676e70;}@property --property-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --operator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f8c49e;}@property --parameter-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f371a6;}@property --var-token-color{syntax: \"<color>\"; inherits: true; initial-value: #cfddd2;}@property --comment-token-color{syntax: \"<color>\"; inherits: true; initial-value: gray;}@property --text-token-color{syntax: \"<color>\"; inherits: true; initial-value: lightgray;}@property --element-token-color{syntax: \"<color>\"; inherits: true; initial-value: salmon;}@property --attribute-color{syntax: \"<color>\"; inherits: true; initial-value: #ffd255;}@property --special-char-token-color{syntax: \"<color>\"; inherits: true; initial-value: #4cdaab;}@property --selector-token-color{syntax: \"<color>\"; inherits: true; initial-value: #daa14c;}@property --prop-token-color{syntax: \"<color>\"; inherits: true; initial-value: #da4cc7;}@property --check-icon-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --copy-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M360-240q-33 0-56.5-23.5T280-320v-480q0-33 23.5-56.5T360-880h360q33 0 56.5 23.5T800-800v480q0 33-23.5 56.5T720-240H360Zm0-80h360v-480H360v480ZM200-80q-33 0-56.5-23.5T120-160v-560h80v560h440v80H200Zm160-240v-480 480Z\";}@property --check-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z\";}*{--_snippet-font: var( --snippet-font, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif );font-family:var(--_snippet-font)}\n/**\n * @license\n * Copyright Slavko Mihajlovic All Rights Reserved.\n *\n * Use of this source code is governed by an ISC-style license that can be\n * found at https://www.isc.org/licenses/\n */\n", ".scope-level-1,.control-keyword-token{color:var(--control-keyword-token-color)}.context-keyword-token{color:var(--context-keyword-token-color)}.scope-level-2,.declaration-keyword-token{color:var(--declaration-keyword-token-color)}.quoted-token{color:var(--quoted-token-color)}.scope-level-3,.data-token{color:var(--data-token-color)}.scope-level-4,.function-token{color:var(--function-token-color)}.separator-token{color:var(--separator-token-color)}.property-token{color:var(--property-token-color)}.scope-level-5,.parameter-token{color:var(--parameter-token-color)}.var-token{color:var(--var-token-color)}.operator-token{color:var(--operator-token-color)}.comment-token{color:var(--comment-token-color)}.text-token{color:var(--text-token-color)}.special-char-token{color:var(--special-char-token-color)}.element-token{color:var(--element-token-color)}.attribute-token{color:var(--attribute-color)}.selector-token{color:var(--selector-token-color)}.css-prop-token{color:var(--prop-token-color)}\n", "*{--rainbow-1: #ff4545;--rainbow-2: #00ff99;--rainbow-3: #006aff;--rainbow-4: #ff0095;--rainbow-5: #ff4545;--effect-blue-1: #5ddcff;--effect-blue-2: #4e76f0;--effect-blue-3: #4e4be7;--effect-green-1: #7efdd7;--effect-green-2: #34c280;--effect-green-3: #058b54;--effect-red-1: #fda0b7;--effect-red-2: #d8418c;--effect-red-3: #970555;--effect-orange-1: #fdeda3;--effect-orange-2: #d8a341;--effect-orange-3: #a76d03}@property --angle{syntax: \"<angle>\"; initial-value: 0deg; inherits: false;}.backlight-blue,.backlight-orange,.backlight-green,.backlight-red,.backlight-rgb{position:relative;border-radius:var(--snippet-border-radius);padding:1.5px}.backlight-blue:after,.backlight-blue:before,.backlight-orange:after,.backlight-orange:before,.backlight-green:after,.backlight-green:before,.backlight-red:after,.backlight-red:before,.backlight-rgb:after,.backlight-rgb:before{content:\"\";position:absolute;width:100%;height:100%;top:50%;left:50%;translate:-50% -50%;border-radius:inherit;animation:6s spin linear infinite}.backlight-blue:after,.backlight-orange:after,.backlight-green:after,.backlight-red:after,.backlight-rgb:after{filter:blur(.2px)}.backlight-blue:before,.backlight-orange:before,.backlight-green:before,.backlight-red:before,.backlight-rgb:before{filter:blur(24px);opacity:.5}.backlight-rgb:after,.backlight-rgb:before{background-image:conic-gradient(from var(--angle),var(--rainbow-1),var(--rainbow-2),var(--rainbow-3),var(--rainbow-4),var(--rainbow-5))}.backlight-blue:after,.backlight-blue:before{background-image:conic-gradient(from var(--angle),var(--effect-blue-1),var(--effect-blue-2),var(--effect-blue-3),var(--effect-blue-1))}.backlight-orange:after,.backlight-orange:before{background-image:conic-gradient(from var(--angle),var(--effect-orange-1),var(--effect-orange-2),var(--effect-orange-3),var(--effect-orange-1))}.backlight-green:after,.backlight-green:before{background-image:conic-gradient(from var(--angle),var(--effect-green-1),var(--effect-green-2),var(--effect-green-3),var(--effect-green-1))}.backlight-red:after,.backlight-red:before{background-image:conic-gradient(from var(--angle),var(--effect-red-1),var(--effect-red-2),var(--effect-red-3),var(--effect-red-1))}@keyframes spin{0%{--angle: 0deg}to{--angle: 360deg}}\n", "*{--rainbow-1: #ff4545;--rainbow-2: #00ff99;--rainbow-3: #006aff;--rainbow-4: #ff0095;--rainbow-5: #ff4545;--effect-blue-1: #5ddcff;--effect-blue-2: #4e76f0;--effect-blue-3: #4e4be7;--effect-green-1: #7efdd7;--effect-green-2: #34c280;--effect-green-3: #058b54;--effect-red-1: #fda0b7;--effect-red-2: #d8418c;--effect-red-3: #970555;--effect-orange-1: #fdeda3;--effect-orange-2: #d8a341;--effect-orange-3: #a76d03}.gutter-neon-green,.gutter-neon-orange,.gutter-neon-red,.header-neon-green,.header-neon-red,.header-neon-orange,.header-neon-blue{position:relative}.header-neon-green:after,.gutter-neon-green:after,.header-neon-red:after,.gutter-neon-red:after,.header-neon-orange:after,.gutter-neon-orange:after,.header-neon-blue:after,.gutter-neon-blue:after{content:\"\";position:absolute}.header-neon-green:after,.header-neon-red:after,.header-neon-orange:after,.header-neon-blue:after{width:100%;height:2px;left:0;top:-1px}.gutter-neon-green:after,.gutter-neon-red:after,.gutter-neon-orange:after,.gutter-neon-blue:after{width:1px;height:100%;right:-1px;bottom:0}.header-neon-blue:after{background-color:var(--effect-blue-1);box-shadow:0 0 20px 2px #4e76f080;-webkit-box-shadow:0px 0px 20px 2px rgba(78,118,240,.5);-moz-box-shadow:0px 0px 20px 2px rgba(78,118,240,.5)}.gutter-neon-blue:after{background-color:var(--effect-blue-1);box-shadow:3px 0 20px 2px #4e76f080;-webkit-box-shadow:3px 0px 20px 2px rgba(78,118,240,.5);-moz-box-shadow:3px 0px 20px 2px rgba(78,118,240,.5)}.header-neon-green:after{background-color:var(--effect-green-1);box-shadow:0 0 20px 2px #34c28080;-webkit-box-shadow:0px 0px 20px 2px rgba(52,194,128,.5);-moz-box-shadow:0px 0px 20px 2px rgba(52,194,128,.5)}.gutter-neon-green:after{background-color:var(--effect-green-1);box-shadow:3px 0 20px 2px #34c28080;-webkit-box-shadow:3px 0px 20px 2px rgba(52,194,128,.5);-moz-box-shadow:3px 0px 20px 2px rgba(52,194,128,.5)}.header-neon-red:after{background-color:var(--effect-red-1);box-shadow:0 0 20px 2px #d8418c80;-webkit-box-shadow:0px 0px 20px 2px rgba(216,65,140,.5);-moz-box-shadow:0px 0px 20px 2px rgba(216,65,140,.5)}.gutter-neon-red:after{background-color:var(--effect-red-1);box-shadow:3px 0 20px 2px #d8418c80;-webkit-box-shadow:3px 0px 20px 2px rgba(216,65,140,.5);-moz-box-shadow:3px 0px 20px 2px rgba(216,65,140,.5)}.header-neon-orange:after{background-color:var(--effect-orange-1);box-shadow:0 0 20px 2px #d8a34180;-webkit-box-shadow:0px 0px 20px 2px rgba(216,163,65,.5);-moz-box-shadow:0px 0px 20px 2px rgba(216,163,65,.5)}.gutter-neon-orange:after{background-color:var(--effect-orange-1);box-shadow:3px 0 20px 2px #d8a34180;-webkit-box-shadow:3px 0px 20px 2px rgba(216,163,65,.5);-moz-box-shadow:3px 0px 20px 2px rgba(216,163,65,.5)}\n"], dependencies: [{ kind: "directive", type: CodeTokenizerDirective, selector: "[codeTokenizer]", inputs: ["format", "tokens"] }, { kind: "directive", type: TemplateTokenizerDirective, selector: "[templateTokenizer]", inputs: ["format"] }, { kind: "directive", type: RecordForCopyDirective, selector: "[recordForCopy]" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.21", ngImport: i0, type: OmniSnippetsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'omni-snippets', imports: [
                        CodeTokenizerDirective,
                        TemplateTokenizerDirective,
                        RecordForCopyDirective,
                        NgIf,
                        NgFor,
                        NgSwitch,
                        NgSwitchCase,
                        NgClass,
                        NgTemplateOutlet,
                    ], providers: [CopyService], template: "<div [ngClass]=\"{\r\n    'backlight-rgb': backlight === 'backlight-RGB',\r\n    'backlight-blue': backlight === 'backlight-Blue',\r\n    'backlight-orange': backlight === 'backlight-Orange',\r\n    'backlight-green': backlight === 'backlight-Green',\r\n    'backlight-red': backlight === 'backlight-Red'\r\n  }\">\r\n  <div class=\"snippets-content\">\r\n    <div class=\"snippets-header\" *ngIf=\"header; else copyBlock\">\r\n      <div *ngFor=\"let snippet of _snippets; let i = index\">\r\n        <div class=\"snippet-tab\" [ngClass]=\"{\r\n            'active-tab': tab === snippet.format\r\n          }\" (click)=\"switchSnippet(snippet.format, i)\">\r\n          {{ snippet.format }}\r\n        </div>\r\n      </div>\r\n      <div class=\"snippet-tab copy-tab\" (click)=\"copySnippet()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\">\r\n          <path />\r\n        </svg>\r\n      </div>\r\n    </div>\r\n    <ng-template #copyBlock>\r\n      <div class=\"copy-button\" (click)=\"copySnippet()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\">\r\n          <path />\r\n        </svg>\r\n      </div>\r\n    </ng-template>\r\n    <div class=\"snippets\" *ngIf=\"_snippets; else templateBlock\">\r\n      <div\r\n        class=\"snippets-gutter\"\r\n        [ngClass]=\"{\r\n          'gutter-neon-blue': neon === 'neon-Blue',\r\n          'gutter-neon-green': neon === 'neon-Green',\r\n          'gutter-neon-red': neon === 'neon-Red',\r\n          'gutter-neon-orange': neon === 'neon-Orange'\r\n        }\"\r\n        #lineNumbers></div>\r\n      <div\r\n        class=\"snippets-code-lines\"\r\n        [ngClass]=\"{\r\n          'header-neon-blue': neon === 'neon-Blue',\r\n          'header-neon-green': neon === 'neon-Green',\r\n          'header-neon-red': neon === 'neon-Red',\r\n          'header-neon-orange': neon === 'neon-Orange'\r\n        }\">\r\n        <div *ngIf=\"_snippets?.length\">\r\n          <div *ngFor=\"let snippet of _snippets; let i = index\" [ngSwitch]=\"snippet.format\">\r\n            <pre codeTokenizer [lineNumbers]=\"lineNumbers\" [format]=\"snippet.format\" [tokens]=\"classifiedTokens[i]\"\r\n              *ngSwitchCase=\"tab\"></pre>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <ng-template #templateBlock>\r\n      <div class=\"snippets\">\r\n        <div\r\n          class=\"snippets-gutter\"\r\n          [ngClass]=\"{\r\n            'gutter-neon-blue': neon === 'neon-Blue',\r\n            'gutter-neon-green': neon === 'neon-Green',\r\n            'gutter-neon-red': neon === 'neon-Red',\r\n            'gutter-neon-orange': neon === 'neon-Orange'\r\n          }\"\r\n          #lineNumbers></div>\r\n        <div\r\n          class=\"snippets-code-lines\"\r\n          [ngClass]=\"{\r\n            'header-neon-blue': neon === 'neon-Blue',\r\n            'header-neon-green': neon === 'neon-Green',\r\n            'header-neon-red': neon === 'neon-Red',\r\n            'header-neon-orange': neon === 'neon-Orange'\r\n          }\">\r\n          <pre recordForCopy templateTokenizer [lineNumbers]=\"lineNumbers\">\r\n            <ng-container *ngTemplateOutlet=\"template\"></ng-container>\r\n          </pre>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </div>\r\n</div>\r\n", styles: [".snippets-content{--_fill-color: var(--snippet-header-text-color);width:inherit;height:inherit;min-height:40px;border-radius:var(--snippet-border-radius);background-color:var(--snippet-background-color);margin:0 auto;overflow:hidden;position:relative;z-index:2}.snippets-content *{background:none}.snippets-content .snippets-header{width:auto;height:auto;display:flex;justify-content:flex-end;background-color:var(--snippet-header-background-color)!important;border-radius:var(--snippet-border-radius) var(--snippet-border-radius) 0 0;font-size:var(--snippets-header-font-size)}.snippets-content .snippets-header .snippet-tab{padding:5px;border-radius:0px 0px var(--snippet-tab-border-radius) var(--snippet-tab-border-radius);color:var(--snippet-header-text-color);cursor:pointer}.snippets-content .snippets-header .snippet-tab:hover{filter:brightness(150%);-webkit-backdrop-filter:brightness(60%);backdrop-filter:brightness(60%)}.snippets-content .snippets-header .active-tab{filter:brightness(150%);-webkit-backdrop-filter:brightness(50%);backdrop-filter:brightness(50%)}.snippets-content .copy-button svg,.snippets-content .snippets-header .copy-tab svg{fill:var(--_fill-color)}.snippets-content .copy-button svg path,.snippets-content .snippets-header .copy-tab svg path{d:path(var(--copy-icon-path))}.snippets-content .copy-button svg:hover,.snippets-content .snippets-header .copy-tab svg:hover{filter:brightness(150%)}.snippets-content .copy-button:active,.snippets-content .snippets-header .copy-tab:active{--copy-icon-path: var(--check-icon-path);--_fill-color: var(--check-icon-color)}.snippets-content .snippets-header .copy-tab svg{height:calc(var(--snippets-header-font-size) - 1px);width:calc(var(--snippets-header-font-size) - 1px)}.snippets-content .copy-button{position:absolute;top:5px;right:5px;display:flex;justify-content:center;align-items:center;background-color:var(--snippet-header-background-color);border-radius:2px;height:calc(var(--snippet-font-size) + 3px);width:calc(var(--snippet-font-size) + 3px)}.snippets-content .copy-button svg{height:calc(var(--snippet-font-size) + 1px);width:calc(var(--snippet-font-size) + 1px)}.snippets-content .snippets-code-lines{min-height:inherit;width:100%;height:100%;border-radius:0 0 var(--snippet-border-radius) var(--snippet-border-radius)}.snippets-content .snippets-code-lines pre{margin:5px 0}.snippets-content .snippets-gutter{display:block;width:var(--snippets-gutter-width);height:100%;min-width:var(--snippets-gutter-width);min-height:inherit;pointer-events:auto;flex-direction:column;align-items:flex-end;color:var(--snippet-header-text-color);padding:5px 0;border-right:1px solid var(--snippet-header-text-color);-webkit-backdrop-filter:brightness(120%);backdrop-filter:brightness(120%)}.snippets-content .snippets-code-lines,.snippets-content .snippets-gutter{font-size:var(--snippet-font-size);letter-spacing:var(--snippet-letter-spacing);height:100%}.snippets-content .selected-line{filter:brightness(130%);background-color:var(--snippet-background-color);-webkit-backdrop-filter:brightness(150%);backdrop-filter:brightness(150%)}.snippets-content .line{display:block;padding-left:10px}.snippets-content .line-focus{-webkit-backdrop-filter:hue-rotate(-25deg);backdrop-filter:hue-rotate(-25deg);border-top:1px solid var(--snippet-header-text-color);border-bottom:1px solid var(--snippet-header-text-color);margin:-1px 0}.snippets-content .snippets{display:flex;flex-direction:row;overflow:auto;min-height:inherit;scrollbar-width:thin;scrollbar-color:var(--snippet-header-text-color) var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar{width:var(--snippets-scrollbar-width);height:var(--snippets-scrollbar-height)}.snippets-content .snippets::-webkit-scrollbar-track{border-radius:2px;background-color:var(--snippet-header-background-color)}.snippets-content .snippets::-webkit-scrollbar-thumb{border-radius:2px;background-color:var(--snippet-header-text-color)}\n", "@property --snippet-font-size{syntax: \"<length>\"; inherits: true; initial-value: 13px;}@property --snippets-header-font-size{syntax: \"<length>\"; inherits: true; initial-value: 12px;}@property --snippet-letter-spacing{syntax: \"<length>\"; inherits: true; initial-value: 1px;}@property --snippet-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 5px;}@property --snippet-tab-border-radius{syntax: \"<length>\"; inherits: true; initial-value: 2px;}@property --snippets-gutter-width{syntax: \"<length>\"; inherits: true; initial-value: 72px;}@property --snippets-scrollbar-width{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippets-scrollbar-height{syntax: \"<length>\"; inherits: true; initial-value: 6px;}@property --snippet-background-color{syntax: \"<color>\"; inherits: true; initial-value: #202836;}@property --snippet-header-background-color{syntax: \"<color>\"; inherits: true; initial-value: #1a212b;}@property --snippet-header-text-color{syntax: \"<color>\"; inherits: true; initial-value: #61789e;}@property --number-line-highlight-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --number-line-hover-color{syntax: \"<color>\"; inherits: true; initial-value: #07cc8a;}@property --control-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #e1955d;}@property --context-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --declaration-keyword-token-color{syntax: \"<color>\"; inherits: true; initial-value: #22e2b8;}@property --quoted-token-color{syntax: \"<color>\"; inherits: true; initial-value: #34ec71;}@property --data-token-color{syntax: \"<color>\"; inherits: true; initial-value: #a98adf;}@property --function-token-color{syntax: \"<color>\"; inherits: true; initial-value: #44b7ff;}@property --separator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #676e70;}@property --property-token-color{syntax: \"<color>\"; inherits: true; initial-value: #ff8c5f;}@property --operator-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f8c49e;}@property --parameter-token-color{syntax: \"<color>\"; inherits: true; initial-value: #f371a6;}@property --var-token-color{syntax: \"<color>\"; inherits: true; initial-value: #cfddd2;}@property --comment-token-color{syntax: \"<color>\"; inherits: true; initial-value: gray;}@property --text-token-color{syntax: \"<color>\"; inherits: true; initial-value: lightgray;}@property --element-token-color{syntax: \"<color>\"; inherits: true; initial-value: salmon;}@property --attribute-color{syntax: \"<color>\"; inherits: true; initial-value: #ffd255;}@property --special-char-token-color{syntax: \"<color>\"; inherits: true; initial-value: #4cdaab;}@property --selector-token-color{syntax: \"<color>\"; inherits: true; initial-value: #daa14c;}@property --prop-token-color{syntax: \"<color>\"; inherits: true; initial-value: #da4cc7;}@property --check-icon-color{syntax: \"<color>\"; inherits: true; initial-value: #38e9ae;}@property --copy-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M360-240q-33 0-56.5-23.5T280-320v-480q0-33 23.5-56.5T360-880h360q33 0 56.5 23.5T800-800v480q0 33-23.5 56.5T720-240H360Zm0-80h360v-480H360v480ZM200-80q-33 0-56.5-23.5T120-160v-560h80v560h440v80H200Zm160-240v-480 480Z\";}@property --check-icon-path{syntax: \"<string>\"; inherits: true; initial-value: \"M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z\";}*{--_snippet-font: var( --snippet-font, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif );font-family:var(--_snippet-font)}\n/**\n * @license\n * Copyright Slavko Mihajlovic All Rights Reserved.\n *\n * Use of this source code is governed by an ISC-style license that can be\n * found at https://www.isc.org/licenses/\n */\n", ".scope-level-1,.control-keyword-token{color:var(--control-keyword-token-color)}.context-keyword-token{color:var(--context-keyword-token-color)}.scope-level-2,.declaration-keyword-token{color:var(--declaration-keyword-token-color)}.quoted-token{color:var(--quoted-token-color)}.scope-level-3,.data-token{color:var(--data-token-color)}.scope-level-4,.function-token{color:var(--function-token-color)}.separator-token{color:var(--separator-token-color)}.property-token{color:var(--property-token-color)}.scope-level-5,.parameter-token{color:var(--parameter-token-color)}.var-token{color:var(--var-token-color)}.operator-token{color:var(--operator-token-color)}.comment-token{color:var(--comment-token-color)}.text-token{color:var(--text-token-color)}.special-char-token{color:var(--special-char-token-color)}.element-token{color:var(--element-token-color)}.attribute-token{color:var(--attribute-color)}.selector-token{color:var(--selector-token-color)}.css-prop-token{color:var(--prop-token-color)}\n", "*{--rainbow-1: #ff4545;--rainbow-2: #00ff99;--rainbow-3: #006aff;--rainbow-4: #ff0095;--rainbow-5: #ff4545;--effect-blue-1: #5ddcff;--effect-blue-2: #4e76f0;--effect-blue-3: #4e4be7;--effect-green-1: #7efdd7;--effect-green-2: #34c280;--effect-green-3: #058b54;--effect-red-1: #fda0b7;--effect-red-2: #d8418c;--effect-red-3: #970555;--effect-orange-1: #fdeda3;--effect-orange-2: #d8a341;--effect-orange-3: #a76d03}@property --angle{syntax: \"<angle>\"; initial-value: 0deg; inherits: false;}.backlight-blue,.backlight-orange,.backlight-green,.backlight-red,.backlight-rgb{position:relative;border-radius:var(--snippet-border-radius);padding:1.5px}.backlight-blue:after,.backlight-blue:before,.backlight-orange:after,.backlight-orange:before,.backlight-green:after,.backlight-green:before,.backlight-red:after,.backlight-red:before,.backlight-rgb:after,.backlight-rgb:before{content:\"\";position:absolute;width:100%;height:100%;top:50%;left:50%;translate:-50% -50%;border-radius:inherit;animation:6s spin linear infinite}.backlight-blue:after,.backlight-orange:after,.backlight-green:after,.backlight-red:after,.backlight-rgb:after{filter:blur(.2px)}.backlight-blue:before,.backlight-orange:before,.backlight-green:before,.backlight-red:before,.backlight-rgb:before{filter:blur(24px);opacity:.5}.backlight-rgb:after,.backlight-rgb:before{background-image:conic-gradient(from var(--angle),var(--rainbow-1),var(--rainbow-2),var(--rainbow-3),var(--rainbow-4),var(--rainbow-5))}.backlight-blue:after,.backlight-blue:before{background-image:conic-gradient(from var(--angle),var(--effect-blue-1),var(--effect-blue-2),var(--effect-blue-3),var(--effect-blue-1))}.backlight-orange:after,.backlight-orange:before{background-image:conic-gradient(from var(--angle),var(--effect-orange-1),var(--effect-orange-2),var(--effect-orange-3),var(--effect-orange-1))}.backlight-green:after,.backlight-green:before{background-image:conic-gradient(from var(--angle),var(--effect-green-1),var(--effect-green-2),var(--effect-green-3),var(--effect-green-1))}.backlight-red:after,.backlight-red:before{background-image:conic-gradient(from var(--angle),var(--effect-red-1),var(--effect-red-2),var(--effect-red-3),var(--effect-red-1))}@keyframes spin{0%{--angle: 0deg}to{--angle: 360deg}}\n", "*{--rainbow-1: #ff4545;--rainbow-2: #00ff99;--rainbow-3: #006aff;--rainbow-4: #ff0095;--rainbow-5: #ff4545;--effect-blue-1: #5ddcff;--effect-blue-2: #4e76f0;--effect-blue-3: #4e4be7;--effect-green-1: #7efdd7;--effect-green-2: #34c280;--effect-green-3: #058b54;--effect-red-1: #fda0b7;--effect-red-2: #d8418c;--effect-red-3: #970555;--effect-orange-1: #fdeda3;--effect-orange-2: #d8a341;--effect-orange-3: #a76d03}.gutter-neon-green,.gutter-neon-orange,.gutter-neon-red,.header-neon-green,.header-neon-red,.header-neon-orange,.header-neon-blue{position:relative}.header-neon-green:after,.gutter-neon-green:after,.header-neon-red:after,.gutter-neon-red:after,.header-neon-orange:after,.gutter-neon-orange:after,.header-neon-blue:after,.gutter-neon-blue:after{content:\"\";position:absolute}.header-neon-green:after,.header-neon-red:after,.header-neon-orange:after,.header-neon-blue:after{width:100%;height:2px;left:0;top:-1px}.gutter-neon-green:after,.gutter-neon-red:after,.gutter-neon-orange:after,.gutter-neon-blue:after{width:1px;height:100%;right:-1px;bottom:0}.header-neon-blue:after{background-color:var(--effect-blue-1);box-shadow:0 0 20px 2px #4e76f080;-webkit-box-shadow:0px 0px 20px 2px rgba(78,118,240,.5);-moz-box-shadow:0px 0px 20px 2px rgba(78,118,240,.5)}.gutter-neon-blue:after{background-color:var(--effect-blue-1);box-shadow:3px 0 20px 2px #4e76f080;-webkit-box-shadow:3px 0px 20px 2px rgba(78,118,240,.5);-moz-box-shadow:3px 0px 20px 2px rgba(78,118,240,.5)}.header-neon-green:after{background-color:var(--effect-green-1);box-shadow:0 0 20px 2px #34c28080;-webkit-box-shadow:0px 0px 20px 2px rgba(52,194,128,.5);-moz-box-shadow:0px 0px 20px 2px rgba(52,194,128,.5)}.gutter-neon-green:after{background-color:var(--effect-green-1);box-shadow:3px 0 20px 2px #34c28080;-webkit-box-shadow:3px 0px 20px 2px rgba(52,194,128,.5);-moz-box-shadow:3px 0px 20px 2px rgba(52,194,128,.5)}.header-neon-red:after{background-color:var(--effect-red-1);box-shadow:0 0 20px 2px #d8418c80;-webkit-box-shadow:0px 0px 20px 2px rgba(216,65,140,.5);-moz-box-shadow:0px 0px 20px 2px rgba(216,65,140,.5)}.gutter-neon-red:after{background-color:var(--effect-red-1);box-shadow:3px 0 20px 2px #d8418c80;-webkit-box-shadow:3px 0px 20px 2px rgba(216,65,140,.5);-moz-box-shadow:3px 0px 20px 2px rgba(216,65,140,.5)}.header-neon-orange:after{background-color:var(--effect-orange-1);box-shadow:0 0 20px 2px #d8a34180;-webkit-box-shadow:0px 0px 20px 2px rgba(216,163,65,.5);-moz-box-shadow:0px 0px 20px 2px rgba(216,163,65,.5)}.gutter-neon-orange:after{background-color:var(--effect-orange-1);box-shadow:3px 0 20px 2px #d8a34180;-webkit-box-shadow:3px 0px 20px 2px rgba(216,163,65,.5);-moz-box-shadow:3px 0px 20px 2px rgba(216,163,65,.5)}\n"] }]
        }], ctorParameters: () => [{ type: TokenizerService }, { type: CopyService, decorators: [{
                    type: Host
                }, {
                    type: Self
                }] }], propDecorators: { template: [{
                type: ContentChild,
                args: [TemplateRef]
            }], backlight: [{
                type: Input
            }], neon: [{
                type: Input
            }], format: [{
                type: Input
            }], header: [{
                type: Input
            }], snippets: [{
                type: Input
            }] } });

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 *
 * Public API Surface of ngx-snippets
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OmniSnippetsComponent };
//# sourceMappingURL=omnidyon-ngx-snippets.mjs.map
