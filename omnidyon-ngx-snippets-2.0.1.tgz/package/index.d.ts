import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @publicApi
 * @description
 * Type representing supported code languages
 */
type Formats = 'JavaScript' | 'TypeScript' | 'HTML' | 'CSS' | 'JSON' | 'Python' | 'SQL' | 'Java' | 'C#' | 'Go' | 'Rust' | 'C' | 'C++';
/**
 * @publicApi
 *  Type representing available backlight effects
 */
type Backlights = 'backlight-RGB' | 'backlight-Blue' | 'backlight-Orange' | 'backlight-Green' | 'backlight-Red';
type Neons = 'neon-RGB' | 'neon-Blue' | 'neon-Orange' | 'neon-Green' | 'neon-Red';

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */

/**
 * @internal
 * @description
 * An interface representing a snippet configuration used to assign the proper
 * tokenizer to a snippet
 */
interface SnippetConfig {
    template: string;
    format: Formats;
}

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */
/**
 * @internal
 * @description
 * An interface representing a classified code token
 */
interface Token {
    token: string;
    class: string;
}
/**
 * @internal
 * @description
 * An interface representing a not classified code token used to preform
 * token classification
 */
interface TokenData {
    token: string;
    priorToken?: string;
    priorPriorToken?: string;
    nextToken?: string;
    secondNextToken?: string;
}

declare class TokenizerService {
    formatterMap: Map<Formats, any>;
    tokenize(text: string, format: Formats): Token[];
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenizerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TokenizerService>;
}

/**
 * Per-snippet clipboard state. Intentionally NOT `providedIn: 'root'` —
 * each <omni-snippets> instance gets its own via the component's
 * `providers: [CopyService]`, otherwise multiple snippets on the same page
 * would stomp each other's clipboard buffer.
 */
declare class CopyService {
    private _textToCopy;
    private _linesToCopy;
    set(text: string): void;
    get(): string;
    add(text: string): void;
    setLine(number: number, line: string): void;
    toClipboard(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CopyService>;
}

/**
 * @license
 * Copyright Slavko Mihajlovic All Rights Reserved.
 *
 * Use of this source code is governed by an ISC-style license that can be
 * found at https://www.isc.org/licenses/
 */

/**
 * @publicApi
 * @description
 * The main component of the library, the actually snippets are being shown from this
 * components view.
 *
 * @usageNotes
 * <omni-snippets
 *  [snippets]="exampleSnippets"  -{@link SnippetConfig}
 *  backlight="backlight-Green"   -{@link Backlights}  effect applied to the snippet
 * ></omni-snippets>
 */
declare class OmniSnippetsComponent {
    private tokenizerService;
    private copyService;
    _snippets: SnippetConfig[];
    tab: string;
    classifiedTokens: Token[][];
    template: TemplateRef<any>;
    constructor(tokenizerService: TokenizerService, copyService: CopyService);
    backlight: Backlights | null;
    neon: Neons;
    format: Formats;
    header: boolean;
    set snippets(snippets: SnippetConfig[]);
    switchSnippet(tab: string, i: number): void;
    copySnippet(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OmniSnippetsComponent, [null, { host: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OmniSnippetsComponent, "omni-snippets", never, { "backlight": { "alias": "backlight"; "required": false; }; "neon": { "alias": "neon"; "required": false; }; "format": { "alias": "format"; "required": false; }; "header": { "alias": "header"; "required": false; }; "snippets": { "alias": "snippets"; "required": false; }; }, {}, ["template"], never, true, never>;
}

export { OmniSnippetsComponent };
export type { Backlights, Formats, Neons, SnippetConfig, Token, TokenData };
